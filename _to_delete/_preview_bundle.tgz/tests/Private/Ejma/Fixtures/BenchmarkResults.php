<?php

namespace Tests\Private\Ejma\Fixtures;

/**
 * PRIVATE (git-ignored): EJMA 9th Ed. §4.14 benchmark results as published on p098, for the
 * inputs in Tests\Unit\Ejma\Fixtures\Benchmarks. Never commit this file.
 */
final class BenchmarkResults
{
    /** @return array<string, float> */
    public static function case1(): array
    {
        return [
            'S1' => 6301, 'S2' => 2645, 'S3' => 495, 'S4' => 17972, 'S5' => 689,
            'S6' => 109067, 'St' => 122681, 'Nc' => 74317, 'Psc' => 93, 'Psi' => 128,
            'fi' => 12562, 'Cp' => 0.7342, 'Cf' => 1.4703, 'Cd' => 1.5324,
            'Kr' => 1.0417, 'e' => 0.2525,
        ];
    }

    /** @return array<string, float> */
    public static function case2(): array
    {
        return [
            'S1' => 4367, 'S1p' => 4741, 'S2' => 6744, 'S3' => 1237, 'S4' => 44925, 'S5' => 1130,
            'S6' => 178830, 'St' => 212274, 'Nc' => 4349, 'Psc' => 210, 'Psi' => 128,
            'fi' => 12562, 'Cp' => 0.7342, 'Cf' => 1.4703, 'Cd' => 1.5324,
            'Kr' => 1.0625, 'e' => 0.4140,
        ];
    }

    /** @return array<string, float> */
    public static function case3(): array
    {
        return [
            'S1' => 3294, 'S1p' => 3613, 'S1pp' => 12105, 'S2' => 3810, 'S2p' => 3929,
            'S3' => 841, 'S4' => 24431, 'S5' => 2003, 'S6' => 253583, 'St' => 273276,
            'Nc' => 8213, 'Psc' => 307, 'fi' => 24548, 'Cp' => 0.7342, 'Cf' => 1.4703,
            'Cd' => 1.5324, 'Kr' => 1.0625, 'e' => 0.3756,
        ];
    }

    /** @return array<string, float> */
    public static function case4(): array
    {
        return [
            'S1' => 8992, 'S1p' => 10407, 'S1pp' => 12975, 'S2' => 5352, 'S2p' => 9520,
            'S3' => 11123, 'S5' => 2529, 'S6' => 87937, 'St' => 123836, 'Nc' => 50710,
            'Psc' => 1851, 'fi' => 15714, 'B1' => 3.7463, 'B2' => 1.0146, 'B3' => 2.3731,
            'e' => 0.3750,
        ];
    }
}
