# EJMA Bellows Calculator — Phase 2 (Assemblies) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add universal, tied universal, hinged and gimbal assemblies (joint level) to the merged Phase 1 EJMA calculator: per-bellows movement distribution, all bellows checks, joint forces/moments and hardware pressure-thrust loads, plus the form, storage and PDF changes.

**Architecture:** Extend the pure-PHP engine in `app/Ejma` (new `AssemblyType`/`AssemblyGeometry`, assembly-aware `Movement`, `Loads`, extra check lines) without changing Phase 1 single-joint behaviour; then extend the existing Laravel form request, controller, migration, mailable and PDF view.

**Tech Stack:** PHP 8.4, Laravel 13, PHPUnit 12, Blade + vanilla JS, dompdf.

**Spec:** `docs/superpowers/specs/2026-10-11-ejma-calculator-phase2-design.md` (Phase 1 spec alongside for unchanged behaviour)

## Global Constraints

- Engine (`app/Ejma/**`) has no Laravel imports; US customary units inside (in, psi, lbf, °F, rad).
- Every Phase 1 test keeps passing unchanged (single-joint behaviour must not move).
- EJMA 9th Ed. PDF: `C:\Users\USER\Downloads\EJMA The Expansion Joint Manufacturers Association Standards -- EJMA Expansion Joint Manufacturers Association.pdf` (scanned, no text). Pre-rendered 110-dpi pages: `C:/Users/USER/AppData/Local/Temp/claude/C--Users-USER-Herd-misubaguna/4efd252f-7755-49e3-adb1-cf9515135e02/scratchpad/ejma/pages/pNNN.png`; render high-res crops with PyMuPDF (`py -3.11`) into that scratchpad dir only. Never commit the PDF or images.
- Page map: §4 page `4-n` = PDF `63+n` (movements p064–p066, Figure 4.1 Ku p067, §4.4 dead weight p068, §4.6 forces p069–p072, §4.7 instability p073); nomenclature p017–p023; benchmarks p097–p098; Appendix C p163; Appendix J p196–p231; §2.5–2.9 applications p031–p046.
- Rulings carried from Phase 1: R3 (EjmaInputException field = public form field name, or `geometry`); R4 (lateral/angular concurrent with compression; e = ec + ee); R5/R6 (CheckLine symbol + comparison); R7 (φ = P / limiting squirm pressure without Cθ); R13 (rate limit counts successful calculations); no calculated value in visitor HTML; no red/orange/amber styling; teal `#0d9488`.
- Tolerances (existing `EjmaAssertions`): stresses/pressures/cycles max(0.5 %, 1); coefficients ±0.001; e/Kr 0.5 %. Documented deviations only with a comment giving published vs computed and which side is conservative.
- Run Pint only on changed files. Commit messages end with `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.
- New public form field names: `assembly_type, Lu, tie_rods, angular_2, spool_weight, spool_angle`.

## Review Focus

1. Universal with `Lu ≤ Lb·2` or `Lu − Lb − x/2 ≤ 0` → field error on `Lu`, not a division error. → Task 1 test.
2. Hinged/gimbal submissions carrying stale axial/lateral values from hidden fields → ignored server-side (x = y = 0). → Task 4 test.
3. Single-joint stored rows from Phase 1 (no `assembly_type`) still render and resend. → Task 4/5 tests.
4. Tied universal with fewer than 2 tie rods → field error on `tie_rods`. → Task 4 test.
5. Gimbal with one plane zero equals hinged with the same angle. → Task 1 test.

---

### Task 1: Assembly model and movement distribution

**Files:**
- Create: `app/Ejma/AssemblyType.php`, `app/Ejma/AssemblyGeometry.php`
- Modify: `app/Ejma/DesignConditions.php`, `app/Ejma/Movement.php`
- Test: `tests/Unit/Ejma/AssemblyMovementTest.php`, extend `tests/Unit/Ejma/Fixtures/Benchmarks.php` with `case2()`

**Interfaces:**
- Produces:
  - `enum AssemblyType: string { Single='single'; Universal='universal'; TiedUniversal='tied_universal'; Hinged='hinged'; Gimbal='gimbal'; public function bellowsCount(): int /* 2 for universal types, else 1 */; public function label(): string }`
  - `final readonly class AssemblyGeometry`: `AssemblyType $type = AssemblyType::Single, ?float $Lu = null, int $tieRods = 0, float $theta2 = 0.0, ?float $Wcs = null, float $thetaU = 0.0`; `static single(): self`; `pins(): int` (hinged 2, gimbal 4, else 0).
  - `DesignConditions` adds trailing `AssemblyGeometry $assembly = new AssemblyGeometry()` (PHP 8.4 `new` in initializer) — existing constructor calls unchanged.
  - `Movement::of(...)` dispatches on `$c->assembly->type`; adds public `float $Ku` (1.5 single) and `float $ey` semantics per assembly; universal Ku per Figure 4.1 (p067) formula; dead-weight x/y (eqs. 4-12/4-13, p068) added when `Wcs` set (needs fi — accept an optional `?float $fi = null` parameter; when null and Wcs set, throw \InvalidArgumentException).
  - `Benchmarks::case2()` — benchmark 2 (universal unreinforced, p097 col 2): Db 24, w 1.44, t .03, n 2, rm .25, q 1, N 4 (per bellows), Lt 1.25, tc .25, Lc 1, Lu 36, P 100, xComp 1, xExt .5, y 2, θ 0, EbRt 28.3e6, EbDt 25.8e6, EcDt 27.3e6, Sy 59726, fatigue ejmaAustenitic(Unreinforced); Sab/Sac/Sar/Cm 20000/20000/20000/1.5. Expected (p098 col 2): S1 4367, S1p 4741, S2 6744, S3 1237, S4 44925, S5 1130, S6 178830, St 212274, Nc 4349, Psc 210, Psi 128, fi 12562, Cp .7342, Cf 1.4703, Cd 1.5324, Kr 1.0625, e .4140.

- [ ] **Step 1: Write failing tests** — `test_benchmark2_e_and_kr` (e .4140, Kr 1.0625); `test_single_unchanged` (case1 e .2525 with default assembly); `test_tied_universal_ignores_axial` (x set → ex = 0); `test_hinged_angular_only` (eθ = θDm/(2N), ex = ey = 0); `test_gimbal_resultant_equals_hinged_when_one_plane_zero`; `test_gimbal_resultant` (θ1 3°, θ2 4° → θ 5°); `test_universal_short_lu_throws_on_Lu`; `test_dead_weight_adds_movement` (Wcs > 0 increases e vs Wcs null).
- [ ] **Step 2: Run** `php artisan test --filter=AssemblyMovementTest` — FAIL.
- [ ] **Step 3: Implement** per spec §3 and pages p064–p068; cite equations in comments.
- [ ] **Step 4: Run** `php artisan test tests/Unit/Ejma` — PASS (Phase 1 unchanged).
- [ ] **Step 5: Commit** `feat(ejma): add assembly types and per-bellows movement distribution`

### Task 2: Assembly-aware checks (benchmark 2, new check lines)

**Files:**
- Modify: `app/Ejma/UnreinforcedBellows.php`, `app/Ejma/ReinforcedBellows.php`, `app/Ejma/ToroidalBellows.php`, `app/Ejma/BuildsCheckLines.php`
- Test: `tests/Unit/Ejma/UniversalBenchmarkTest.php`, `tests/Unit/Ejma/MovementLimitChecksTest.php`

**Interfaces:**
- Consumes: Task 1 (`DesignConditions::$assembly`, `Movement`).
- Produces: Psc uses N × `bellowsCount()` (notes to 4-35/4-49/4-60); new lines `movement_ec_max` (symbol `ec`, limit q − 2rm − nt, U-shaped only, §4.2 p066), `movement_ee_max` (symbol `ee`, limit 6rm − q, U-shaped only), `instability_axial` (symbol `ex`, limit 1.25·Dm²/(N_total²·q), §4.7 p073, all types); values add `Ku`, `assembly` (string not allowed in float values — store the assembly type in CheckResult notes instead: "Assembly: Universal (2 bellows; checks apply to each bellows)").

- [ ] **Step 1: Write failing tests** — `test_benchmark_2` (every key of `case2()['expected']`, normal tolerance; document any deviation per Global Constraints); `test_new_limit_lines_present_for_single` (case1 has the three lines with correct limits); `test_toroidal_has_only_instability_line`; `test_universal_psc_uses_total_convolutions`.
- [ ] **Step 2: Run** — FAIL.
- [ ] **Step 3: Implement.**
- [ ] **Step 4: Run** `php artisan test tests/Unit/Ejma` — PASS; benchmarks 1, 3, 4 unchanged.
- [ ] **Step 5: Commit** `feat(ejma): assembly-aware squirm and movement-limit checks verified by benchmark 2`

### Task 3: Joint loads, hardware thrust, facade

**Files:**
- Modify: `app/Ejma/Loads.php`, `app/Ejma/EjmaCalculator.php`, `app/Ejma/CalculationRequest.php` (no signature change needed if assembly travels in DesignConditions)
- Test: `tests/Unit/Ejma/JointLoadsTest.php`, `tests/Unit/Ejma/AppendixJTest.php`

**Interfaces:**
- Produces: `Loads::of(...)` returns existing keys plus `fw` (lbf/in per convolution; given fw else fi if St ≤ 1.5·Sy else 0.67·fi, §1.3 p022), `Fa` (4-14), `M_theta` (4-16), `M_lateral` (4-15), `V_lateral` (4-17 single / 4-18 universal), `hardware_total` and `hardware_per_component` (tied universal: thrust, thrust/tieRods; hinged: thrust, thrust/2; gimbal: thrust, thrust/2; else absent). All lbf / in·lbf.
- `AppendixJTest`: extract from Appendix J (p196–p231) every joint-level quantity of examples 1–6 and 9 that lies within scope (ex/ey/eθ/e, Fa, Ml, Mθ, Vl, pressure thrust) and assert them; cite example number and page in each test name/comment. Quantities requiring piping-system equilibrium are out of scope — list them in a comment as skipped.

- [ ] **Step 1: Write failing tests** — `JointLoadsTest`: fw rule both branches; Fa/Mθ/Ml/Vl formulas; per-component hardware loads per assembly; single/universal have no hardware keys. `AppendixJTest` as above.
- [ ] **Step 2: Run** — FAIL.
- [ ] **Step 3: Implement**; `EjmaCalculator` merges loads into values and adds the assembly note.
- [ ] **Step 4: Run** `php artisan test tests/Unit/Ejma` — PASS.
- [ ] **Step 5: Commit** `feat(ejma): joint forces, moments and hardware thrust per assembly`

### Task 4: Storage, form, validation, controller

**Files:**
- Create: `database/migrations/2026_10_11_000002_add_assembly_type_to_ejma_calculations_table.php`
- Modify: `app/Models/EjmaCalculation.php`, `app/Http/Requests/EjmaCalculationRequest.php`, `app/Http/Controllers/PublicSite/EjmaCalculatorController.php`, `resources/views/public/toolkit/ejma-bellows-calculator.blade.php`
- Test: `tests/Feature/EjmaAssemblyFormTest.php`

**Interfaces:**
- Consumes: Tasks 1–3.
- Produces: column `assembly_type` string nullable default 'single'; form select `assembly_type` (single default) with options labelled by `AssemblyType::label()`; fields `Lu` (mm/in, universal types), `tie_rods` (int ≥ 2, tied universal), `angular_2` (deg, gimbal), `spool_weight` (N/lbf, optional, universal types), `spool_angle` (deg, optional, required when spool_weight given); axial fields disabled + ignored server-side for tied universal (axial) and hinged/gimbal (axial and lateral); bounds per unit system like Phase 1.

- [ ] **Step 1: Write failing tests** — each assembly type valid submission stores the row with `assembly_type` and shows only verdict/reference; universal without `Lu` → error on `Lu`; tied universal with `tie_rods=1` → error on `tie_rods`; hinged with stale `x_comp`/`lateral` → stored US inputs have x = y = 0; Phase 1 single payload without `assembly_type` still works (defaults single); no calculated values in HTML.
- [ ] **Step 2: Run** `php artisan test --filter=EjmaAssemblyFormTest` — FAIL.
- [ ] **Step 3: Implement** (JS shows/hides assembly fields like bellows-type fields; required markers type-aware).
- [ ] **Step 4: Run** full suite — PASS. Browser check via `php artisan serve` on a temp sqlite DB with temporary material data that is NOT committed.
- [ ] **Step 5: Commit** `feat(ejma): assembly selection on the calculator form`

### Task 5: Report and PDF

**Files:**
- Modify: `app/Mail/EjmaCalculationReport.php`, `resources/views/pdf/ejma-calculation.blade.php`, `resources/views/emails/ejma-calculation.blade.php`
- Test: extend `tests/Feature/EjmaReportTest.php`

**Interfaces:**
- Consumes: stored `assembly_type`, values keys from Task 3, notes from Tasks 2–3.
- Produces: subject `EJMA calc {ref} — {company} — {Db mm} mm {assembly label lowercased unless single} {bellows type} — {VERDICT}` (single keeps the Phase 1 subject exactly); PDF "Assembly" section (type, per-bellows ex/ey/eθ/e, Ku, Fa, Mθ, Ml, Vl, pressure thrust, hardware total and per component, both unit systems) placed before the checks table; universal states "Checks apply to each of the 2 bellows".

- [ ] **Step 1: Write failing tests** — universal subject contains "universal"; single subject unchanged; PDF HTML for tied universal contains the per-rod load; PDF for a Phase 1 row without assembly_type renders.
- [ ] **Step 2: Run** — FAIL.
- [ ] **Step 3: Implement**; render a sample universal PDF into the scratchpad and view page 1.
- [ ] **Step 4: Run** full suite — PASS.
- [ ] **Step 5: Commit** `feat(ejma): assembly section in the calculation report`
