<?php
    $yieldTitle = trim($__env->yieldContent('title'));
    $yieldDescription = trim($__env->yieldContent('meta_description'));

    $seoTitle = $seo['meta_title'] ?? $seo->meta_title ?? ($yieldTitle ?: ($seo['title'] ?? $seo->title ?? config('app.name')));
    $seoTitle = \App\Support\PublicSeo::title($seoTitle);

    $seoDescription = $seo['meta_description'] ?? $seo->meta_description ?? ($yieldDescription ?: ($seo['excerpt'] ?? $seo->excerpt ?? $seo['summary'] ?? $seo->summary ?? \App\Support\PublicSeo::DEFAULT_DESC));
    $seoDescription = \App\Support\PublicSeo::description($seoDescription);

    $rawCanonical = $seo['canonical_url'] ?? $seo->canonical_url ?? request()->path();
    $canonicalUrl = \App\Support\PublicSeo::canonicalUrl($rawCanonical);

    $ogTitle = $seo['og_title'] ?? $seo->og_title ?? $seoTitle;
    $ogDescription = $seo['og_description'] ?? $seo->og_description ?? $seoDescription;
    $ogImageRaw = ($seo['og_image_path'] ?? $seo->og_image_path ?? null) ?: \App\Support\PublicSeo::DEFAULT_OG_IMAGE;
    // The wide logo crops badly in link previews; use the 1200x630 share image instead.
    if (str_contains($ogImageRaw, 'misuba-logo')) {
        $ogImageRaw = \App\Support\PublicSeo::DEFAULT_OG_IMAGE;
    }
    $ogImagePath = \App\Support\PublicSeo::assetUrl($ogImageRaw);
    $ogImageSize = str_starts_with($ogImageRaw, 'http') ? null : @getimagesize(public_path(rawurldecode(ltrim($ogImageRaw, '/'))));
    if ($ogImageRaw === \App\Support\PublicSeo::DEFAULT_OG_IMAGE) {
        $ogImageSize = [1200, 630];
    }
    $ogType = $seo['og_type'] ?? 'website';
    $ogLocale = $seo['og_locale'] ?? (app()->getLocale() === 'id' ? 'id_ID' : 'en_US');
    // Pages with a version in the other language: ['en' => path, 'id' => path].
    $alternates = $seo['alternates'] ?? [];

    $robotsIndex = (bool)($seo['robots_index'] ?? $seo->robots_index ?? true);
    $robotsFollow = (bool)($seo['robots_follow'] ?? $seo->robots_follow ?? true);
    $schemaJson = $seo['schema_json'] ?? $seo->schema_json ?? null;
?>

<title><?php echo e($seoTitle); ?></title>
<?php if($seoDescription): ?>
<meta name="description" content="<?php echo e($seoDescription); ?>">
<?php endif; ?>
<link rel="canonical" href="<?php echo e($canonicalUrl); ?>">
<?php $__currentLoopData = $alternates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altLang => $altPath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<link rel="alternate" hreflang="<?php echo e($altLang); ?>" href="<?php echo e(\App\Support\PublicSeo::canonicalUrl($altPath)); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(isset($alternates['en'])): ?>
<link rel="alternate" hreflang="x-default" href="<?php echo e(\App\Support\PublicSeo::canonicalUrl($alternates['en'])); ?>">
<?php endif; ?>
<meta name="robots" content="<?php echo e($robotsIndex ? 'index' : 'noindex'); ?>, <?php echo e($robotsFollow ? 'follow' : 'nofollow'); ?>, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

<!-- Open Graph / Facebook / LinkedIn / WhatsApp -->
<meta property="og:type" content="<?php echo e($ogType); ?>">
<meta property="og:site_name" content="PT Misuba Guna Indonesia">
<meta property="og:title" content="<?php echo e($ogTitle); ?>">
<?php if($ogDescription): ?>
<meta property="og:description" content="<?php echo e($ogDescription); ?>">
<?php endif; ?>
<meta property="og:url" content="<?php echo e($canonicalUrl); ?>">
<meta property="og:image" content="<?php echo e($ogImagePath); ?>">
<?php if($ogImageSize): ?>
<meta property="og:image:width" content="<?php echo e($ogImageSize[0]); ?>">
<meta property="og:image:height" content="<?php echo e($ogImageSize[1]); ?>">
<?php endif; ?>
<meta property="og:image:alt" content="<?php echo e($ogTitle); ?>">
<meta property="og:locale" content="<?php echo e($ogLocale); ?>">
<?php $__currentLoopData = $alternates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altLang => $altPath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($altLang !== app()->getLocale()): ?>
<meta property="og:locale:alternate" content="<?php echo e($altLang === 'id' ? 'id_ID' : 'en_US'); ?>">
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($ogTitle); ?>">
<?php if($ogDescription): ?>
<meta name="twitter:description" content="<?php echo e($ogDescription); ?>">
<?php endif; ?>
<meta name="twitter:image" content="<?php echo e($ogImagePath); ?>">

<!-- AI / LLM Discovery Standard Link -->
<link rel="alternate" type="text/plain" href="https://misubaguna.com/llms.txt" title="LLM summary of PT Misuba Guna Indonesia">
<link rel="alternate" type="application/xml" href="https://misubaguna.com/sitemap.xml" title="Sitemap">

<?php if($schemaJson): ?>
<script type="application/ld+json">
<?php echo is_array($schemaJson) ? json_encode($schemaJson, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : $schemaJson; ?>

</script>
<?php endif; ?>
<?php /**PATH C:\Users\USER\Herd\misubaguna\resources\views/public/partials/seo.blade.php ENDPATH**/ ?>