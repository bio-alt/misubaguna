<?php

namespace Tests\Private\Ejma;

use App\Ejma\Coefficients;
use PHPUnit\Framework\TestCase;
use Tests\RequiresEjmaData;
use Tests\Unit\Ejma\EjmaAssertions;

/**
 * PRIVATE (git-ignored): checks the installed Appendix I tables against published EJMA values
 * (Tables I1–I4, the Appendix I worked example and the §4.14 benchmark coefficients).
 * Never commit this file.
 */
class CoefficientTablesTest extends TestCase
{
    use EjmaAssertions;
    use RequiresEjmaData;

    public function test_appendix_example(): void
    {
        // EJMA Appendix I worked example (T = 0.63, M = 2.3), eqs. I-3 to I-5.
        $a = 0.322 + 0.6 * (0.315 - 0.322);
        $b = 0.272 + 0.6 * (0.260 - 0.272);
        $expected = $a + 0.6 * ($b - $a);

        $this->assertCoefficient($expected, Coefficients::cp(0.63, 2.3), 'Cp example');
    }

    public function test_exact_grid_points_return_table_values(): void
    {
        $this->assertSame(0.272, Coefficients::cp(0.60, 2.5));
        $this->assertSame(1.000, Coefficients::cp(0.0, 0.2));
        $this->assertSame(0.119, Coefficients::cp(1.0, 4.0));
        $this->assertSame(2.501, Coefficients::cf(1.0, 0.2));
        $this->assertSame(2.800, Coefficients::cd(1.0, 1.0));
        $this->assertSame(23.3, Coefficients::b1(20));
        $this->assertSame(1.0, Coefficients::b2(0));
        $this->assertSame(10.0, Coefficients::b3(20));
    }

    public function test_benchmark_points(): void
    {
        $tp = 0.03 * sqrt(24 / 25.5);
        $T = Coefficients::T(0.25, 1.44);
        $M = Coefficients::M(0.25, 25.5, $tp);

        $this->assertCoefficient(0.7342, Coefficients::cp($T, $M), 'Cp');
        $this->assertCoefficient(1.4703, Coefficients::cf($T, $M), 'Cf');
        $this->assertCoefficient(1.5324, Coefficients::cd($T, $M), 'Cd');
    }

    public function test_toroidal_benchmark(): void
    {
        $dm = 27.496;
        $tp = 0.05 * sqrt(24 / $dm);
        $x = 6.61 * 1 ** 2 / ($dm * $tp);

        $this->assertCoefficient(3.7463, Coefficients::b1($x), 'B1');
        $this->assertCoefficient(1.0146, Coefficients::b2($x), 'B2');
        $this->assertCoefficient(2.3731, Coefficients::b3($x), 'B3');
    }

    public function test_table_shape(): void
    {
        $tables = require Coefficients::defaultDataFile();

        $this->assertSame(['cp', 'cf', 'cd', 'b'], array_keys($tables));
        foreach (['cp', 'cf', 'cd'] as $key) {
            $this->assertSame(
                ['0.2', '0.4', '0.6', '0.8', '1.0', '1.2', '1.4', '1.6', '2.0', '2.5', '3.0', '3.5', '4.0'],
                array_map('strval', array_keys($tables[$key])),
                $key,
            );
            foreach ($tables[$key] as $row) {
                $this->assertCount(21, $row, $key);
            }
        }
        $this->assertSame(range(0, 20), array_keys($tables['b']));
    }
}
