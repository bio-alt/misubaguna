<?php

namespace Tests\Private\Ejma;

use App\Ejma\AssemblyGeometry;
use App\Ejma\AssemblyType;
use App\Ejma\BellowsGeometry;
use App\Ejma\BellowsType;
use App\Ejma\CheckResult;
use App\Ejma\Derived;
use App\Ejma\DesignConditions;
use App\Ejma\Loads;
use App\Ejma\Movement;
use PHPUnit\Framework\TestCase;
use Tests\Unit\Ejma\EjmaAssertions;

/**
 * PRIVATE (git-ignored): quotes published EJMA Appendix J values. Never commit this file.
 *
 * EJMA 9th Ed. Appendix J examples (PDF p196–p231): joint-level quantities only, computed
 * with each example's own manufacturer data (Dm, fw given, N, Lb, Lu) so that the given fw is used.
 *
 * Tolerance: the examples print intermediate results rounded to 3 decimals (e.g. ex = .034 for
 * 0.405/12 = 0.03375) and carry the rounded value forward. Each assertion therefore accepts
 * max(0.5 %, the effect of half a unit in the last printed digit of the rounded input), stated
 * per assertion. Larger differences are documented deviations (published vs computed, which
 * side is conservative).
 *
 * Documented deviations
 *  D1 Lateral shear Vl (eqs. 4-17/4-18, p069): every example evaluates Vl = fw·Dm·ey / (2Lb)
 *     or / (2Lu), i.e. at the neutral length, while the printed equations carry (Lb ± x) /
 *     (Lu ± x). The engine takes the compression position (−x), consistent with ruling R4 and
 *     with ey (eq. 4-7 / 4-6 already uses Lb − x / Lu − Lb − x/2). The engine value is larger
 *     by Lb/(Lb − x) (conservative). Both are asserted: the neutral-length formula reproduces the
 *     published figure; the engine value equals published·Lb/(Lb − x) within rounding.
 *  D2 Ku (Example 9, p223): read from the chart as 1.33 at Lu/2Lb = 1.8; the formula printed
 *     on Figure 4.1 (p067) gives 1.3195. ey scales with Ku, so engine ey is 0.8 % lower
 *     (unconservative by the chart-reading difference). Asserted after rescaling by 1.33/Ku.
 *  D3 Tied universal (Example 4, p206): x = 0.248 in. is the pipe growth between the tie-rod
 *     plates and compresses the bellows (ruling P2-R3, p065 note under eq. 4-6); the engine's
 *     tied universal uses it in ex, ey and ec, with anchor Fa = 0 and Vl over Lu, so it
 *     reproduces the example directly.
 *  D4 Pressure thrust: the examples use Fs = Ae·P with the manufacturer's effective area
 *     Ae = 510.7 in² (= π/4·25.5², p216). The engine uses π·Dm²/4, which is the same area.
 *
 * Skipped (system-level, need piping equilibrium or out of scope):
 *  - Ex 1 (p198): anchor forces Fx = ±(Fs + Fa).
 *  - Ex 2 (p200–p201): anchor/DMA forces Fx, Fy and moments Mz at A, B, C.
 *  - Ex 3 (p204): Fs = Fa = 0 at anchors (tied), anchor moments Mz; tied single is not an engine
 *    assembly (asserted as a single joint with x = 0, which is what the example does).
 *  - Ex 4 (p207–p208): anchor forces/moments at A and B.
 *  - Ex 5 (p210–p213): pressure-balanced joint (out of scope): balancing-bellows ex = .109,
 *    Fx = fw(ex flow + ex balancing) = 6447, flange forces/moments. Only the flow-bellows pair,
 *    which is a universal arrangement, is asserted.
 *  - Ex 6 (p216–p217): Fp = Ap·Pd (nozzle area), vessel/nozzle/anchor forces and moments.
 *  - Ex 7 (p218–p219): hinge rotations from system geometry (§2.8 out of scope).
 *  - Ex 8 (p221–p222): Fx, Fy at the intermediate anchors and M1, M2 (system equilibrium);
 *    the per-hinge eθ and Mθ are asserted.
 *  - Ex 9 (p224–p225): condition 2 (x = .5 extension with y = .5): the example evaluates lateral
 *    concurrent with extension, ec = ey − ex = .025 and ee = ey + ex = .125; the engine places
 *    lateral at the compression position (R4 / P2-R4), giving ec = ee(limit check) = ey = .075
 *    (higher ec, conservative; lower ee, unconservative by .05 here — see the task report).
 *    The cold-spring combination e = .305 (§4.5, out of scope).
 *  D5 ee for the §4.2 extension limit (ruling P2-R4): Movement::eeLimitCheck = max(ey + eθ − |ex|,
 *     eθ/Kθ − |ex|, ex ext) reproduces Appendix J's ee = ey + eθ − |ex| for compressed positions
 *     (Ex 9 case 1 condition 1, case 2 cold spring and operating) up to the D2 Ku difference.
 *  - Ex 10 (rectangular), Ex 11 (straight pipe expansion): out of scope.
 */
class AppendixJTest extends TestCase
{
    use EjmaAssertions;

    private const FW = 36840.0;

    private const DM = 25.5;

    private static function geometry(float $Dm, int $N, float $Lb, float $fw): BellowsGeometry
    {
        $w = 1.0;
        $t = 0.05;

        return new BellowsGeometry(
            type: BellowsType::Unreinforced, Db: $Dm - $w - $t, t: $t, n: 1, N: $N, q: $Lb / $N,
            w: $w, rm: 0.2, Lt: 1.0, fw: $fw,
        );
    }

    private static function conditions(AssemblyGeometry $a, float $P, float $xComp = 0.0, float $xExt = 0.0, float $y = 0.0, float $theta = 0.0): DesignConditions
    {
        return new DesignConditions(P: $P, xComp: $xComp, xExt: $xExt, y: $y, theta: $theta, requiredCycles: null, assembly: $a);
    }

    /** @return array<string, float> */
    private static function loads(BellowsGeometry $g, DesignConditions $c): array
    {
        // fi/St/Sy are irrelevant: the example's fw is given, so the §1.3 rule is not applied.
        $result = new CheckResult(BellowsType::Unreinforced, [], ['fi' => $g->fw, 'St' => 0.0, 'Ktheta' => 1.0]);

        return Loads::of($g, $c, Derived::of($g, $c), $result, 30000.0);
    }

    private static function movement(BellowsGeometry $g, DesignConditions $c): Movement
    {
        return Movement::of($g, $c, Derived::of($g, $c));
    }

    /** |actual − published| ≤ max(0.5 % of published, $rounding). */
    private function assertPublished(float $published, float $actual, float $rounding, string $label): void
    {
        $this->assertEqualsWithDelta($published, $actual, max(0.005 * abs($published), $rounding) + 1e-9, $label);
    }

    /** Example 1 (p197–p198): single joint, axial only. Ae = 510.7 in², fw = 36840, N = 12, P = 150, x = 2.17. */
    public function test_example_1_single_axial(): void
    {
        $Dm = sqrt(4 * 510.7 / M_PI);   // D4: Dm from the manufacturer's Ae
        $g = self::geometry($Dm, 12, 12.0, self::FW);
        $c = self::conditions(AssemblyGeometry::single(), 150.0, xComp: 2.17);
        $m = self::movement($g, $c);
        $L = self::loads($g, $c);

        $this->assertPublished(0.181, $m->exComp, 0.0005, 'ex = x/N (eq. 4-1), p198');
        $this->assertPublished(76605, $L['thrust'], 1.0, 'Fs = Ae·Pd, p198');
        // Fa = (36840)(0.181) = 6668 with ex rounded; ±fw·0.0005 = 18 lbf.
        $this->assertPublished(6668, $L['Fa'], self::FW * 0.0005, 'Fa = fw·ex (eq. 4-14), p198');
    }

    /** Example 2 (p199–p200): single joint, axial and lateral. Dm = 25.5, Lb = 12, N = 12, P = 125, x = .405, y = .216. */
    public function test_example_2_single_axial_lateral(): void
    {
        $g = self::geometry(self::DM, 12, 12.0, self::FW);
        $c = self::conditions(AssemblyGeometry::single(), 125.0, xComp: 0.405, y: 0.216);
        $m = self::movement($g, $c);
        $L = self::loads($g, $c);

        $this->assertPublished(0.034, $m->exComp, 0.0005, 'ex (eq. 4-1), p200');
        $this->assertPublished(0.119, $m->ey, 0.0005, 'ey = 3Dm·y/(N(Lb − x)) (eq. 4-7), p200');
        $this->assertPublished(63838, $L['thrust'], 1.0, 'Fs = Ae·Pd, p200');
        $this->assertPublished(1253, $L['Fa'], self::FW * 0.0005, 'Fa (eq. 4-14), p200');

        // D1: published Vl = fw·Dm·ey/(2Lb) = 4658; ±fw·Dm·0.0005/24 = 19.6 for ey rounding.
        $this->assertPublished(4658, Loads::lateralShear(self::FW, self::DM, $m->ey, 12.0), 19.6, 'Vl neutral length, p200');
        // Engine: compression position Lb − x → 4658·12/11.595 (+3.5 %, conservative).
        $this->assertPublished(4658 * 12 / 11.595, $L['V_lateral'], 19.6 * 12 / 11.595, 'Vl engine (Lb − x)');
        $this->assertGreaterThan(4658, $L['V_lateral']);
    }

    /** Example 3 (p202–p203): tied single joint, lateral only (x = 0). Lb = 24, N = 18, y = .984, P = 135. */
    public function test_example_3_tied_single_lateral(): void
    {
        $g = self::geometry(self::DM, 18, 24.0, self::FW);
        $c = self::conditions(AssemblyGeometry::single(), 135.0, y: 0.984);
        $m = self::movement($g, $c);
        $L = self::loads($g, $c);

        $this->assertSame(0.0, $m->exComp, 'ex = 0, tie rods prevent axial displacement, p203');
        $this->assertPublished(0.174, $m->ey, 0.0005, 'ey (eq. 4-7), p203');
        // P2-R4: lateral only → the extended side of each convolution moves ey: eeLimitCheck = ey.
        $this->assertSame($m->ey, $m->eeLimitCheck, 'eeLimitCheck = ey');
        $this->assertPublished(0.174, $m->eeLimitCheck, 0.0005, 'eeLimitCheck = .174');
        // x = 0: engine and published Vl coincide; ±fw·Dm·0.0005/48 = 9.8 for ey rounding.
        $this->assertPublished(3405, $L['V_lateral'], 9.8, 'Vl = fw·Dm·ey/(2Lb) (eq. 4-17), p203');
    }

    /** Example 4 (p205–p207): tied universal, lateral in two planes. Lu = 48, Lb = 12, N = 12, x = .248, yy = .788, yz = 1.463. */
    public function test_example_4_tied_universal_two_planes(): void
    {
        $g = self::geometry(self::DM, 12, 12.0, self::FW);
        $untied = new AssemblyGeometry(type: AssemblyType::Universal, Lu: 48.0);
        $tied = new AssemblyGeometry(type: AssemblyType::TiedUniversal, Lu: 48.0, tieRods: 4);

        // D3 (ruling P2-R3): x between the tie-rod plates compresses the bellows of the tied joint.
        $my = self::movement($g, self::conditions($tied, 100.0, xComp: 0.248, y: 0.788));
        $mz = self::movement($g, self::conditions($tied, 100.0, xComp: 0.248, y: 1.463));
        $this->assertCoefficient(1.285, $my->Ku, 'Ku at Lu/2Lb = 2 (Figure 4.1), p206');
        $this->assertPublished(0.010, $my->exComp, 0.0005, 'ex = x/(2N) (eq. 4-2), p206');
        $this->assertPublished(0.030, $my->ey, 0.0005, '(ey)y (eq. 4-6), p206');
        $this->assertPublished(0.056, $mz->ey, 0.0005, '(ey)z (eq. 4-6), p206');
        // ec = ey + |ex| (eq. 4-8, θ = 0) per the example's movements: .030 + .010 and .056 + .010.
        $this->assertPublished(0.040, $my->ec, 0.001, 'ec y-plane = (ey)y + ex');
        $this->assertPublished(0.066, $mz->ec, 0.001, 'ec z-plane = (ey)z + ex');
        // The untied universal with the same x gives the same per-bellows movements.
        $this->assertEqualsWithDelta($my->ey, self::movement($g, self::conditions($untied, 100.0, xComp: 0.248, y: 0.788))->ey, 1e-12);

        // D1: published Vl = fw·Dm·ey/(2Lu); ±fw·Dm·0.0005/96 = 4.9 for ey rounding.
        $this->assertPublished(294, Loads::lateralShear(self::FW, self::DM, $my->ey, 48.0), 4.9, '(Vl)y (eq. 4-18), p207');
        $this->assertPublished(548, Loads::lateralShear(self::FW, self::DM, $mz->ey, 48.0), 4.9, '(Vl)z (eq. 4-18), p207');

        // Engine tied universal: Vl over Lu (as the example), anchor Fa = 0, tie rods carry fw·ex.
        $Ly = self::loads($g, self::conditions($tied, 100.0, xComp: 0.248, y: 0.788));
        $Lz = self::loads($g, self::conditions($tied, 100.0, xComp: 0.248, y: 1.463));
        $this->assertSame(0.0, $Ly['Fa'], 'Fa = 0, ex restrained by tie rods, p207');
        $this->assertEqualsWithDelta(self::FW * 0.248 / 24, $Ly['tie_rod_axial'], 1e-6, 'tie-rod share fw·ex');
        $this->assertPublished(294, $Ly['V_lateral'], 4.9, '(Vl)y engine tied');
        $this->assertPublished(548, $Lz['V_lateral'], 4.9, '(Vl)z engine tied');
    }

    /** Example 5 (p209–p212): flow-bellows pair of a pressure-balanced joint as a universal. Dm = 68, fw = 35425, N = 6, Lb = 12, Lu = 60, x = .876. */
    public function test_example_5_flow_bellows_universal(): void
    {
        $fw = 35425.0;
        $g = self::geometry(68.0, 6, 12.0, $fw);
        $a = new AssemblyGeometry(type: AssemblyType::Universal, Lu: 60.0);
        $my = self::movement($g, self::conditions($a, 14.7, xComp: 0.876, y: 0.44));
        $mz = self::movement($g, self::conditions($a, 14.7, xComp: 0.876, y: 0.12));

        // Ku = 1.22 read from the chart at Lu/2Lb = 2.5; formula 1.2245 (+0.4 %).
        $this->assertEqualsWithDelta(1.22, $my->Ku, 0.005, 'Ku at Lu/2Lb = 2.5, p211');
        $this->assertPublished(0.073, $my->exComp, 0.0005, 'ex flow = x/(2Nf), p211');
        $this->assertPublished(0.064, $my->ey, 0.0005, '(ey)y (eq. 4-6), p211');
        // (ey)z: published .017 = 1.22·68·0.12/570.7 = 0.01744; engine 0.01751 with Ku = 1.2245.
        $this->assertPublished(0.017, $mz->ey, 0.0006, '(ey)z (eq. 4-6), p211 (chart Ku and rounding)');

        // D1 (neutral length 2Lu): (Vl)y = 1285; ±fw·Dm·0.0005/120 = 10.0.
        $this->assertPublished(1285, Loads::lateralShear($fw, 68.0, $my->ey, 60.0), 10.0, '(Vl)y (eq. 4-18), p212');
        // (Vl)z = 341 uses ey rounded down to .017: with the published ey the formula reproduces it;
        // the engine's ey (0.01751) gives 351 (+3 %, conservative).
        $this->assertPublished(341, Loads::lateralShear($fw, 68.0, 0.017, 60.0), 1.0, '(Vl)z with published ey, p212');
        $this->assertEqualsWithDelta(351.4, Loads::lateralShear($fw, 68.0, $mz->ey, 60.0), 0.5, '(Vl)z engine ey');
    }

    /** Example 6 (p214–p216): single joint at a vessel nozzle. Dm = 25.5, N = 12, Lb = 12, P = 150, x = .760, y = .543. */
    public function test_example_6_single_nozzle(): void
    {
        $g = self::geometry(self::DM, 12, 12.0, self::FW);
        $c = self::conditions(AssemblyGeometry::single(), 150.0, xComp: 0.760, y: 0.543);
        $m = self::movement($g, $c);
        $L = self::loads($g, $c);

        $this->assertPublished(0.063, $m->exComp, 0.0005, 'ex (eq. 4-1), p215');
        $this->assertPublished(0.308, $m->ey, 0.0005, 'ey (eq. 4-7), p215');
        $this->assertPublished(2321, $L['Fa'], self::FW * 0.0005, 'Fa (eq. 4-14), p216');
        $this->assertPublished(76605, $L['thrust'], 1.0, 'Fs = Ae·Pd, Ae = π/4·Dm² = 510.7, p216');

        // D1: published Vl = 12056 at 2Lb; engine at Lb − x = 11.24 → +6.8 % (conservative).
        $this->assertPublished(12056, Loads::lateralShear(self::FW, self::DM, $m->ey, 12.0), 19.6, 'Vl neutral length, p216');
        $this->assertPublished(12056 * 12 / 11.24, $L['V_lateral'], 19.6 * 12 / 11.24, 'Vl engine (Lb − x)');
    }

    /** Example 8 (p221–p222): three hinged joints, θ = .019, .072, .053 rad. Dm = 25.5, N = 12. */
    public function test_example_8_hinge_angular_moments(): void
    {
        $g = self::geometry(self::DM, 12, 12.0, self::FW);
        // [θ, published eθ, published Mθ]; Mθ carries eθ rounding: ±(fw·Dm·0.0005/4 + 0.5) = 118 in·lbf.
        foreach (['A' => [0.019, 0.020, 4697], 'B' => [0.072, 0.077, 18084], 'C' => [0.053, 0.056, 13152]] as $hinge => [$theta, $et, $Mt]) {
            $c = self::conditions(new AssemblyGeometry(type: AssemblyType::Hinged), 100.0, theta: $theta);
            $m = self::movement($g, $c);
            $L = self::loads($g, $c);
            $this->assertPublished($et, $m->etheta, 0.0005, "eθ{$hinge} = θDm/(2N) (eq. 4-3), p222");
            $this->assertPublished($Mt, $L['M_theta'], 118.0, "Mθ{$hinge} (eq. 4-16), p222");
        }
    }

    /** Example 9 (p223–p225): universal, Dm = 29.5, N = 5, q = 2 (Lb = 10), Lu = 36. */
    public function test_example_9_universal_equivalent_movements(): void
    {
        $g = self::geometry(29.5, 5, 10.0, self::FW);
        $a = new AssemblyGeometry(type: AssemblyType::Universal, Lu: 36.0);

        // Case 1, conditions 1 (x = 1 comp, y = 1.5) and 2 (x = .5 ext, y = .5): one engine run.
        $m = self::movement($g, self::conditions($a, 50.0, xComp: 1.0, xExt: 0.5, y: 1.5));
        // D2: Figure 4.1 formula vs the chart reading 1.33.
        $this->assertEqualsWithDelta(2808 / 2128, $m->Ku, 1e-12, 'Ku formula at Lu/2Lb = 1.8 (p067)');
        $chart = 1.33 / $m->Ku;
        $this->assertPublished(0.231, $m->ey * $chart, 0.0005, 'cond. 1 ey (eq. 4-6), p224 (chart Ku)');
        $this->assertPublished(0.10, $m->exComp, 0.0005, 'cond. 1 ex = x/(2N), p224');
        $this->assertPublished(0.331, $m->ey * $chart + $m->etheta + $m->exComp, 0.0005, 'cond. 1 ec = ey + eθ + |ex|, p224');
        // Engine ec with the formula Ku: 0.3290 vs 0.331 published (−0.6 %, D2).
        $this->assertPublished(0.331, $m->ec, 0.0025, 'cond. 1 ec engine (D2)');
        // D5: ee = ey + eθ − |ex| = .231 − .100 = .131 (p224); engine 0.129 with the formula Ku (D2).
        $this->assertEqualsWithDelta($m->ey - $m->exComp, $m->eeLimitCheck, 1e-12, 'eeLimitCheck = ey − ex');
        $this->assertPublished(0.131, $m->ey * $chart - $m->exComp, 0.0005, 'cond. 1 ee, p224 (chart Ku)');
        $this->assertPublished(0.131, $m->eeLimitCheck, 0.0025, 'cond. 1 ee engine (D2)');
        $this->assertPublished(0.050, $m->exExt, 0.0005, 'cond. 2 ex = x/(2N) extension, p224');
        // Cond. 2 lateral 0.5 in. at the extension position (eq. 4-5, Lu − Lb + x/2).
        $m2 = self::movement($g, self::conditions($a, 50.0, xExt: 0.5, y: 0.5));
        $this->assertPublished(0.075, $m2->eyExt * $chart, 0.0005, 'cond. 2 ey (eq. 4-5), p224 (chart Ku)');

        // Case 2 (p225): the individual positions (cold spring y = .5, x = .25; operating y = 1, x = 1).
        $cs = self::movement($g, self::conditions($a, 50.0, xComp: 0.25, y: 0.5));
        $this->assertPublished(0.076, $cs->ey * $chart, 0.0005, 'cold-spring ey, p225 (chart Ku)');
        $this->assertPublished(0.025, $cs->exComp, 0.0005, 'cold-spring ex, p225');
        $this->assertPublished(0.101, $cs->ec - $cs->ey + $cs->ey * $chart, 0.0005, 'cold-spring ec, p225 (chart Ku)');
        $this->assertPublished(0.051, $cs->eeLimitCheck - $cs->ey + $cs->ey * $chart, 0.0005, 'cold-spring ee = ey − ex, p225 (chart Ku)');
        $op = self::movement($g, self::conditions($a, 50.0, xComp: 1.0, y: 1.0));
        $this->assertPublished(0.154, $op->ey * $chart, 0.0005, 'operating ey, p225 (chart Ku)');
        $this->assertPublished(0.100, $op->exComp, 0.0005, 'operating ex, p225');
        $this->assertPublished(0.254, $op->ec - $op->ey + $op->ey * $chart, 0.0005, 'operating ec, p225 (chart Ku)');
        $this->assertPublished(0.054, $op->eeLimitCheck - $op->ey + $op->ey * $chart, 0.0005, 'operating ee = ey − ex, p225 (chart Ku)');
        $this->assertPublished(0.054, $op->eeLimitCheck, 0.0015, 'operating ee engine 0.0527 (D2)');
    }
}
