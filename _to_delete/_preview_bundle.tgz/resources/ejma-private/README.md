# resources/ejma-private — private EJMA Standard data

This directory holds material reproduced from the EJMA Standards (9th Ed., 2008), which is
copyrighted. The GitHub repository is public, so **this directory is git-ignored and must never
be committed** (see `.gitignore`). Do not paste its contents into tracked files, issues or PRs.

## Contents

| Path | What it is |
| --- | --- |
| `coefficients.php` | Appendix I Tables I1–I4: Cp, Cf, Cd (keyed by M, columns T = 0.0 … 1.0) and B1/B2/B3 (keyed by x). Returns `['cp' => …, 'cf' => …, 'cd' => …, 'b' => …]`; loaded lazily by `App\Ejma\Coefficients`. |
| `docs/appendix-i-transcription.md` | Transcription and proof-reading sheet for the Appendix I tables. |
| `docs/2026-10-11-ejma-calculator-phase1.md` | Phase 1 implementation plan (quotes the tables and §4.14 benchmark results). |
| `docs/2026-10-11-ejma-calculator-phase2.md` | Phase 2 implementation plan (quotes benchmark and Appendix J values). |
| `docs/2026-10-11-ejma-calculator-phase1-design.md` | Phase 1 design spec (quotes benchmark results). |

The matching private tests (§4.14 benchmark results, Appendix I/J published values) live in
`tests/Private/` (also git-ignored except its README) and run as the `Private` PHPUnit suite.

## Without this directory

`Coefficients::available()` returns false. The calculator page shows the "being prepared —
contact us" notice, a POST is rejected as a validation error, and engine tests that need the
tables are skipped rather than failed. This is the expected state of the GitHub Actions
staging deploy.

## Deploying

The deploy script only does `git pull`, so this directory is never delivered by git. Copy it to
the server by hand whenever it changes, e.g. from the project root:

```sh
scp -r resources/ejma-private <user>@<host>:<app-dir>/resources/
```

Then confirm on the server: `php -r 'require "vendor/autoload.php"; var_dump(App\Ejma\Coefficients::available());'`
prints `bool(true)`. Keep a backup copy outside the repository as well.

## materials.php

ASME BPVC Section II Part D (Metric, 2019) allowable stress (Tables 1A/1B, plate, non-G5 rows),
yield strength (Table Y-1) and modulus (Tables TM-1/TM-4) for the calculator materials.
Loaded by config/ejma/materials.php. Copy to the server alongside coefficients.php.
