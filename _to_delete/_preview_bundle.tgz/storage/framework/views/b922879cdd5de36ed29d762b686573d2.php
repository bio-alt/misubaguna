<!DOCTYPE html>
<html>
<body style="font-family: Arial, sans-serif; color: #0f172a; font-size: 14px;">
    <h2 style="color: #2b9d9f;">New Job Application</h2>
    <table cellpadding="6" style="border-collapse: collapse;">
        <tr><td><strong>Position</strong></td><td><?php echo e($application->position); ?></td></tr>
        <tr><td><strong>Name</strong></td><td><?php echo e($application->name); ?></td></tr>
        <tr><td><strong>Email</strong></td><td><a href="mailto:<?php echo e($application->email); ?>"><?php echo e($application->email); ?></a></td></tr>
        <tr><td><strong>Phone / WhatsApp</strong></td><td><?php echo e($application->phone); ?></td></tr>
        <tr><td><strong>CV</strong></td><td><?php echo e($application->cv_original_name); ?> (attached)</td></tr>
    </table>
    <?php if($application->cover_letter): ?>
        <h3>Cover Letter</h3>
        <p style="white-space: pre-line;"><?php echo e($application->cover_letter); ?></p>
    <?php endif; ?>
    <hr>
    <p style="color: #64748b; font-size: 12px;">Application #<?php echo e($application->id); ?> sent from the career form at <?php echo e(url('/career/')); ?>. Reply to this email to respond directly to the applicant.</p>
</body>
</html>
<?php /**PATH C:\Users\USER\Herd\misubaguna\resources\views/emails/career-application.blade.php ENDPATH**/ ?>