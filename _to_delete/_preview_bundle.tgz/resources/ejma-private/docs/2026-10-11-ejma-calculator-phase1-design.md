# EJMA Bellows Calculator — Phase 1 Design

**Date:** 2026-10-11
**Status:** Draft for review
**Reference:** EJMA Standards, 9th Edition (2008) — the copy the company owns

## 1. Purpose

A public engineering tool on misubaguna.com that runs EJMA bellows design checks and turns
each calculation into a qualified sales lead. Visitors enter their bellows design and
conditions; the full calculation goes to the company by email (with a PDF calculation
sheet). The visitor sees only an overall pass/fail verdict and a reference number, and is
invited to contact the company for the detailed results.

Success criteria:

- Engine results match the EJMA §4.14 benchmark calculations (cases 1, 3, 4) within tolerance.
- Every valid submission is stored and reaches `MAIL_CONTACT_TO` with the PDF attached.
- No calculated values (stresses, cycles, pressures) are exposed in the page, its source, or
  any client-side code.

## 2. Phasing

The full tool is delivered in three phases, each with its own spec, plan, and release.

| Phase | Scope | Verification |
|---|---|---|
| **1 (this spec)** | Single expansion joints; unreinforced, reinforced, toroidal bellows; **check mode** (visitor supplies geometry); form, storage, email + PDF | EJMA §4.14 benchmarks 1, 3, 4 |
| 2 | Assemblies: universal, tied universal, hinged, gimbal, 3-hinge systems — movement distribution per bellows and hardware loads (no hardware sizing) | Benchmark 2, Appendix J examples |
| 3 | **Design mode**: search for a geometry that passes all checks within company tooling limits | Reuses Phase 1–2 tests plus search tests |

**Out of scope in all phases** (the form directs such visitors to contact the company):
rectangular joints, pressure-balanced joints, external pressure (§4.15), design temperatures
in the creep range (Appendix G), restraint hardware sizing, flow-induced vibration and
internal sleeve sizing (§4.10–4.11), bellows torsion (§4.13.4), reinforced bellows with
fastener-joined reinforcing members or equalizing rings (Phase 1 supports integral
reinforcing members only, R = R1).

## 3. Architecture

Server-side PHP inside the existing Laravel 13 app. The calculation runs only on the server;
EJMA equations are never shipped to the browser.

```
Browser form ──POST──▶ EjmaCalculatorController
                         ├─ validate (FormRequest)
                         ├─ Units::toUs()            ── metric → in/psi/lbf/°F
                         ├─ App\Ejma engine          ── CheckResult
                         ├─ EjmaCalculation::create  ── stored (inputs, results, contact)
                         ├─ Mail (HTML + PDF)        ── MAIL_CONTACT_TO, Reply-To visitor
                         └─ redirect → result screen (verdict + ref + email button)
```

### 3.1 Engine — `app/Ejma/` (pure PHP, no Laravel dependencies)

| Unit | Responsibility |
|---|---|
| `Units` | Metric ⇄ US customary conversion at the boundary. The engine works only in in, psi, lbf, °F. |
| `Coefficients` | Cp, Cf, Cd (Appendix I tables, interpolated per §1.2) and B1, B2, B3 for toroidal bellows (linear interpolation). Tables are PHP arrays transcribed from the standard. |
| `BellowsInput` | Immutable value object: bellows type, geometry, materials (resolved properties), design conditions, movements. Derives shared quantities (Dm, tp, Ac, Kr, k, α, etc.). |
| `Checker` interface | `check(BellowsInput): CheckResult` |
| `UnreinforcedBellows` | §4.13.1, eq. 4-27 – 4-37 |
| `ReinforcedBellows` | §4.13.2, eq. 4-38 – 4-50 |
| `ToroidalBellows` | §4.13.3, eq. 4-51 – 4-61 |
| `Movement` | Equivalent axial movement per convolution `e` from axial, lateral, angular movement (§4.1–4.2); compression and extension cases. |
| `Fatigue` | `Nc = (c / (St − b))^a` with a, b, c from the material data; per-type St definition. |
| `Stability` | Column squirm Psc and in-plane squirm Psi (where EJMA defines it for the type). |
| `Loads` | Spring rate per convolution and overall, pressure thrust, spring force at given movement. |
| `CheckResult` | List of `CheckLine` (symbol, description, value, limit expression, limit value, margin, pass/fail/not-evaluated, EJMA equation number) plus overall verdict and informational values (fi, Kr, e, thrust, forces). |

Pressure-capacity limits follow the notes under each equation group, e.g. `S1, S2 ≤ Cwb·Sab`,
`S1′ ≤ Cwc·Sac`, `S3 + S4 ≤ Cm·Sab` (below creep range). The creep-range forms are not
implemented; creep-range temperatures are rejected by validation.

**Overall verdict:** PASS only when every check line passes, design pressure ≤ Psc
(and ≤ Psi where applicable), and Nc ≥ required cycles. If any check is *not evaluated*
(e.g. missing fatigue constants), the verdict is **"Needs engineering review"**, not PASS.

### 3.2 Material and tooling data — files in the repo

- `config/ejma/materials.php` — one entry per material, in metric units (°C, MPa, GPa):
  id, display name, family (`austenitic` / `nickel` / `other`), roles (bellows, collar,
  reinforcement), allowable stress Sa (table by temperature), elastic modulus E (table by
  temperature, must include room temperature 20 °C), annealed yield strength (table by
  temperature, must include 20 °C), maximum temperature below the creep range, and
  **optional** fatigue constants a, b, c per bellows type.
- Seeded entries: SS304, SS304L, SS316, SS316L, SS321, Inconel 625, Incoloy 800, Incoloy 825,
  and carbon steel SA-516-70 (collar/reinforcement role only).
  **Values are left empty and filled by the company's engineers**; a material without Sa
  and E data is hidden from the form.
- Values are interpolated linearly by temperature; temperatures outside a table's range are
  rejected.
- **Cm and Sy are derived, not entered** (EJMA §1.3): Cm = 1.5 for annealed bellows, or
  1.5·Ysm clamped to [1.5, 3.0] for as-formed bellows, where Ysm is a polynomial in Kf·εf
  (different polynomials for austenitic and nickel families; Ysm = 1 for `other`),
  Kf = 1.0 for expanding mandrel / roll forming and 0.6 for hydraulic, elastomeric or
  pneumatic forming, and εf is the forming strain from the geometry.
  Sy = 0.67·Cm·Sym·Syh/Syc, with Syc and Syh the annealed yield at room and design
  temperature from the data file and Sym defaulting to Syc (an advanced input may supply
  the certified test-report value).
- Fatigue: EJMA Figure 4.20 gives constants **per bellows type** for austenitic stainless
  steel only (unreinforced, reinforced, toroidal). These are built into the engine for the
  `austenitic` family. Other families need manufacturer correlation-test constants
  (§4.12.1.8) in the data file. If none are given, fatigue is reported as "requires
  manufacturer fatigue data" and the verdict becomes "Needs engineering review".
- Changes are made by editing the file and deploying via the existing git push/pull flow;
  git history records who changed which value.
- `config/ejma/tooling.php` is **not** part of Phase 1 (used by Phase 3).

Advanced-mode visitors may override Sab, E (RT and DT) and Sy for the bellows material.
Overrides are flagged in the email and PDF.

### 3.3 Storage — `ejma_calculations` table

| Column | Notes |
|---|---|
| id | |
| reference | Unique, `EJ-YYYY-NNNN` (sequence per year) |
| bellows_type | unreinforced / reinforced / toroidal |
| verdict | pass / fail / review |
| inputs | JSON — as entered (metric or US) plus the converted US values |
| results | JSON — serialized `CheckResult` |
| contact | JSON — name, company, email, phone, notes |
| ip_address | for abuse tracing |
| emailed_at | nullable; null if mail sending failed |
| timestamps | |

An artisan command `ejma:resend {reference}` regenerates the PDF and resends the email
(for failed sends or a lost email).

## 4. User-facing flow

### 4.1 Page

`/toolkit/ejma-bellows-calculator/` — same layout, teal accent, and compact type as the
existing toolkit pages; added to the `/toolkit/` hub, the sitemap, and `llms.txt`.

### 4.2 Form (single page, sectioned)

1. **Bellows type** — unreinforced / reinforced / toroidal; fields for other types are hidden.
2. **Design conditions** — design pressure, design temperature, required cycle life,
   movements: axial compression, axial extension, lateral, angular.
3. **Geometry** — common: Db, w, q, t, n, N, Lt, collar (tc, Lc, collar material);
   type-specific: rm (unreinforced/reinforced); Ar, Atc, Zc, ng, fw, Ld, reinforcement
   material (reinforced); r, Dr, Ld, Ar, Atc, Zc, ng (toroidal). Each field has a short label,
   unit, and a reference to a dimension diagram.
4. **Materials & fabrication** — bellows, collar, reinforcement material (from the data file);
   condition (annealed / as-formed) and forming method (together with geometry these set
   Cm); weld joint efficiencies Cwb, Cwc, Cwr (default 1.0); optional working spring rate
   fw (defaults per §1.3); collapsible **Advanced** overrides (Sab, E at RT and DT, Sy,
   Sym).
5. **Contact** — name, company, email, phone (required); notes (optional).

Unit toggle: Metric (default: mm, bar(g), °C, degrees) / US (in, psi, °F). The toggle only
relabels fields and sets a hidden `units` value; conversion happens on the server.

### 4.3 Validation

Server-side `FormRequest`: required fields per bellows type, numeric ranges, and geometric
consistency (e.g. positive dimensions, convolution height larger than the ply thickness,
material temperature within its data range and below the creep range). Errors are shown
inline on the fields with input preserved.

### 4.4 Result screen

Shown after a successful submission. Contains **only**:

- Overall verdict: "✅ Your design passes all EJMA checks", "❌ Your design does not pass
  EJMA checks", or "⚠ Your design needs engineering review".
- Reference number, e.g. **EJ-2026-0042**.
- Message: the full calculation has been sent to our engineering team; contact us to
  receive the detailed results.
- **Email button**: `mailto:` the contact address with subject
  `EJMA calculation EJ-2026-0042`.

No stresses, cycles, pressures, margins, or which checks failed.

### 4.5 Spam and abuse

Reuses the contact form's approach: hidden honeypot field, and rate limiting at
5 submissions per hour per IP (`throttle:5,60`).

## 5. Email and PDF

- To `config('mail.contact_to')`, Reply-To the visitor. Sent synchronously (the app uses
  `QUEUE_CONNECTION=sync`); failures are reported and `emailed_at` stays null, but the
  visitor still gets the result screen because the calculation is stored.
- Subject: `EJMA calc EJ-2026-0042 — <Company> — <Db> mm <type> — <VERDICT>[ (<first failing check>)]`.
- HTML body: contact details, design summary, table of check lines with pass/fail.
- **PDF attachment** (`barryvdh/laravel-dompdf`), `EJ-2026-0042.pdf`:
  1. Header: reference, date, company, "Calculated per EJMA Standards, 9th Edition".
  2. Inputs in both unit systems; material properties used, with overrides flagged.
  3. Derived geometry and coefficients (Cp, Cf, Cd or B1–B3, Kr, e, …).
  4. Every check line: symbol, value, limit expression, limit value, margin %, PASS/FAIL,
     EJMA equation number.
  5. Fatigue, squirm, spring rate, pressure thrust and forces.
  6. Disclaimer: preliminary calculation for quotation purposes, to be confirmed by
     PT Misuba Guna Indonesia engineering; not a substitute for a certified design.

## 6. Testing

### 6.1 Engine unit tests — `tests/Unit/Ejma/`

- **Benchmarks** (§4.14) cases 1 (single unreinforced), 3 (single reinforced), 4 (single
  toroidal): feed the published inputs and assert every published result
  (S1, S1′, S1″, S2, S2′, S3, S4, S5, S6, St, Nc, Psc, Psi, fi, Kr, e) within ±0.5%
  (or ±1 unit for values below 200). The benchmark uses Figure 4.20 fatigue constants for
  austenitic stainless steel, which the test supplies directly.
- **Coefficients**: Cp 0.7342, Cf 1.4703, Cd 1.5324, B1 3.7463, B2 1.0146, B3 2.3731 at the
  benchmark points, ±0.001. These tests are the main guard against errors in transcribing
  the Appendix I tables.
- Unit conversion round trips; temperature interpolation of material data.
- Missing fatigue constants → fatigue line *not evaluated*, verdict *review*.
- Creep-range temperature → rejected.

### 6.2 Feature tests — `tests/Feature/EjmaCalculatorTest.php`

- Page renders; hub card, sitemap entry and `llms.txt` entry exist.
- Valid submission → row stored with a reference, mail sent to `mail.contact_to` with a PDF
  attachment, result screen shows the verdict, reference and a `mailto:` link containing the
  reference, and **the response HTML contains no calculated values**.
- Invalid submission → field errors, nothing stored, no mail.
- Honeypot → no row stored, no mail; rate limit → 429 after 5 submissions.
- Mail failure → row stored with `emailed_at` null, visitor still sees the result screen.
- `ejma:resend` resends and sets `emailed_at`.

### 6.3 Engineering sign-off before go-live

A transcription verification sheet listing the Appendix I tables as entered in code next to
the source page references, for a company engineer to spot-check (tests only cover the
values at the benchmark points). The material data file must be populated by the company's
engineers before go-live.

## 7. Copyright

The EJMA Standard is copyrighted. Equations are implemented in server-side code only; no
text, tables, or figures from the standard are published on the website. The PDF cites
equation numbers and shows computed values only. The standard's PDF is not committed to the
repository.

## 8. Open items for the company

- Populate `config/ejma/materials.php` (Sa, E and annealed-yield tables; creep threshold;
  fatigue constants for nickel alloys where available).
- Spot-check the coefficient transcription sheet.
