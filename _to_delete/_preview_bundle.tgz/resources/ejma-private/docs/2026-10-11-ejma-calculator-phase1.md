# EJMA Bellows Calculator — Phase 1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A gated public EJMA bellows check calculator (single joints; unreinforced, reinforced, toroidal) that stores each calculation, emails the full results with a PDF to the company, and shows the visitor only a verdict, a reference number and an email button.

**Architecture:** A pure-PHP engine in `app/Ejma/` (value objects, coefficient tables, one checker per bellows type, a facade) verified against EJMA §4.14 benchmarks; a Laravel web layer (FormRequest → engine → `ejma_calculations` row → Mailable with dompdf PDF → flash result screen) following the existing toolkit and contact-form patterns.

**Tech Stack:** PHP 8.4, Laravel 13, PHPUnit 12, Blade + vanilla JS, `barryvdh/laravel-dompdf`.

**Spec:** `docs/superpowers/specs/2026-10-11-ejma-calculator-phase1-design.md`

## Global Constraints

- Engine (`app/Ejma/**`) has **no** Laravel imports; it computes only in US customary units (in, psi, lbf, °F, radians).
- Reference standard: EJMA Standards **9th Edition (2008)**; every check line cites its EJMA equation number.
- Source PDF: `C:\Users\USER\Downloads\EJMA The Expansion Joint Manufacturers Association Standards -- EJMA Expansion Joint Manufacturers Association.pdf` (239 scanned pages, no text layer). **Never commit it or rendered pages.** Render pages to a temp dir to read them:
  `py -3.11 -c "import pymupdf,sys; d=pymupdf.open(sys.argv[1]); [d[i-1].get_pixmap(dpi=130).save(f'{sys.argv[2]}/p{i:03d}.png') for i in range(1,240)]" "<pdf>" "<tempdir>"`
- PDF page map (PDF page = printed page): §1.3 nomenclature p017–p023 (1-6…1-12); §4 page `4-n` = PDF `63+n` (§4.1–4.3 movements p064–p066, §4.12.1.6 squirm p086–p089, §4.13 equations p091–p096, §4.14 benchmarks p097–p098, Figures 4.13–4.15 p099, Figure 4.20 p104); Appendix I tables p190–p195; Appendix J p196–p231.
- No EJMA text, tables or figures on public pages; no calculated value in any visitor-facing response.
- Page URL `/toolkit/ejma-bellows-calculator/`; route names `public.toolkit.ejma-calculator` (GET) and `public.toolkit.ejma-calculator.store` (POST, `throttle:5,60`).
- Reference format `EJ-YYYY-NNNN`, sequence restarting each year.
- Mail recipient `config('mail.contact_to')`, Reply-To the visitor.
- Visual style per existing toolkit pages: teal accent `#0d9488`, compact type, no red/orange, no `<header>` element in page content.
- Work on branch `feature/ejma-calculator` in a worktree from `main` HEAD; do not touch the user's uncommitted files in the main checkout.
- Test tolerance helper (Task 1): stresses/pressures/cycles pass when `|actual − expected| ≤ max(0.005·|expected|, 1)`; coefficients pass within ±0.001; e and Kr within 0.5 %.

## Review Focus

1. Lateral movement where `Lb − x ≤ 0` in eq. 4-7 (very short bellows, large compression) — expect a field error on `x_comp`, not a division-by-zero 500. → test in Task 3.
2. Geometry whose Cp/Cf/Cd parameters (T = 2rm/w, M = 1.82rm/√(Dm·tp)) or toroidal x = 6.61r²/(Dm·tp) fall outside the Appendix I tables — expect a field error "outside EJMA chart range", not an exception. → tests in Task 2 and Task 9.
3. `St ≤ b` in the fatigue equation (very small movements) — expect Nc reported as "no fatigue limit" and the fatigue line to pass, not NAN/negative cycles. → test in Task 4.
4. Design temperature above a material's creep threshold or outside its data table, or a material id without data posted by a tampered form — expect field errors, nothing stored. → tests in Task 7 and Task 9.
5. Mail transport failure — expect the row stored with `emailed_at = null` and the visitor still shown the verdict. → test in Task 10.

---

### Task 1: Engine foundations — enums, units, value objects, test helper

**Files:**
- Create: `app/Ejma/BellowsType.php`, `app/Ejma/MaterialFamily.php`, `app/Ejma/FormingCondition.php`, `app/Ejma/FormingMethod.php`, `app/Ejma/Units.php`, `app/Ejma/BellowsGeometry.php`, `app/Ejma/DesignConditions.php`, `app/Ejma/BellowsProperties.php`, `app/Ejma/FatigueConstants.php`, `app/Ejma/EjmaInputException.php`
- Test: `tests/Unit/Ejma/UnitsTest.php`, `tests/Unit/Ejma/EjmaAssertions.php` (trait)

**Interfaces:**
- Produces:
  - `enum BellowsType: string { Unreinforced='unreinforced'; Reinforced='reinforced'; Toroidal='toroidal'; }`
  - `enum MaterialFamily: string { Austenitic='austenitic'; Nickel='nickel'; Other='other'; }`
  - `enum FormingCondition: string { Annealed='annealed'; AsFormed='as_formed'; }`
  - `enum FormingMethod: string { MandrelOrRoll='mandrel_roll'; HydraulicElastomericPneumatic='hydraulic'; public function kf(): float /* 1.0 | 0.6 */ }`
  - `final class Units` static: `mmToIn, inToMm, barToPsi (×14.5037738), psiToBar, cToF, fToC, mpaToPsi (×145.037738), gpaToPsi (×145037.738), degToRad, radToDeg, lbfToN (×4.44822162), nToLbf`, each `(float): float`.
  - `final readonly class BellowsGeometry` (US units, public props): `BellowsType $type, float $Db, float $t, int $n, int $N, float $q, ?float $w, ?float $rm, ?float $Lt, float $tc = 0, float $Lc = 0, ?float $Ld = null, float $Ar = 0, float $Atc = 0, float $Zc = 0, int $ng = 0, ?float $r = null, ?float $Dr = null, ?float $DmToroidal = null, ?float $fw = null`
  - `final readonly class DesignConditions`: `float $P /*psig*/, float $xComp, float $xExt, float $y, float $theta /*rad*/, ?int $requiredCycles`
  - `final readonly class FatigueConstants`: `float $a, float $b, float $c`; `static ejmaAustenitic(BellowsType): self` → unreinforced (3.4, 54000, 1.86e6), reinforced (2.9, 41800, 5.18e6), toroidal (3.25, 41800, 2.30e6) (Figure 4.20, p104).
  - `final readonly class BellowsProperties`: `float $EbRt, float $EbDt, float $EcDt, float $ErDt, float $Sab, float $Sac, float $Sar, float $Sy, float $Cm, float $Cwb = 1.0, float $Cwc = 1.0, float $Cwr = 1.0, ?FatigueConstants $fatigue`
  - `final class EjmaInputException extends \DomainException` with `public readonly string $field` (form field name the error belongs to).
  - Trait `Tests\Unit\Ejma\EjmaAssertions`: `assertEjmaValue(float $expected, float $actual, string $label)`, `assertCoefficient(...)`, `assertRatio(...)` implementing the Global Constraints tolerances.

- [ ] **Step 1: Write failing tests** `UnitsTest`: `test_pressure_round_trip` (10 bar → 145.037738 psi → 10 bar, delta 1e-9), `test_temperature` (`cToF(400) === 752.0`, `fToC(752) === 400.0`), `test_modulus` (`gpaToPsi(195) ≈ 28282359`, ±1), `test_angle` (`degToRad(5) ≈ 0.0872665`).
- [ ] **Step 2: Run** `php artisan test --filter=UnitsTest` — Expected: FAIL (class not found).
- [ ] **Step 3: Implement** all files listed. Value objects only validate nothing; validation lives in the facade (Task 7).
- [ ] **Step 4: Run** `php artisan test --filter=UnitsTest` — Expected: PASS.
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): add engine enums, units and value objects"`

### Task 2: Coefficients (Appendix I) + transcription sheet

**Files:**
- Create: `app/Ejma/Coefficients.php`, `docs/ejma/appendix-i-transcription.md`
- Test: `tests/Unit/Ejma/CoefficientsTest.php`

**Interfaces:**
- Consumes: `EjmaInputException` (Task 1)
- Produces: `final class Coefficients` static: `cp(float $T, float $M): float`, `cf(float $T, float $M): float`, `cd(float $T, float $M): float`, `b1(float $x): float`, `b2(float $x): float`, `b3(float $x): float`; plus `T(float $rm, float $w): float` (= 2rm/w, eq. I-1), `M(float $rm, float $Dm, float $tp): float` (= 1.82rm/√(Dm·tp), eq. I-2). Out-of-range input throws `EjmaInputException` with field `geometry` and message "outside EJMA chart range".

- [ ] **Step 1: Write failing tests**
  - `test_appendix_example` — the worked example on p190: `cp(0.63, 2.3)` equals the value obtained by eqs. I-3…I-5 from the four corners 0.322/0.315/0.272/0.260 (compute by hand in the test: A = 0.322 + 0.6·(0.315−0.322), B = 0.272 + 0.6·(0.260−0.272), Cp = A + 0.6·(B−A)).
  - `test_benchmark_points` — with the case-1 geometry (rm 0.25, w 1.44, Dm 25.5, tp = 0.03·√(24/25.5)): `cp ≈ 0.7342`, `cf ≈ 1.4703`, `cd ≈ 1.5324` (±0.001).
  - `test_toroidal_benchmark` — x for case 4 (r 1, Dm 27.496, tp = 0.05·√(24/27.496)): `b1 ≈ 3.7463`, `b2 ≈ 1.0146`, `b3 ≈ 2.3731` (±0.001).
  - `test_out_of_range_throws` — `cp(1.2, 2.0)` and `b1(30)` throw `EjmaInputException`.
- [ ] **Step 2: Run** `php artisan test --filter=CoefficientsTest` — Expected: FAIL.
- [ ] **Step 3: Transcribe** Tables I1 (Cp), I2 (Cf), I3 (Cd), I4 (B1–B3) from p191–p195 into `private const` arrays keyed `[M][T]` (and `[x]` for B). Interpolate per eqs. I-1…I-5 (bilinear: first along T, then along M); B-factors linear in x. Values exactly as printed.
- [ ] **Step 4: Run** `php artisan test --filter=CoefficientsTest` — Expected: PASS. If a benchmark point is off, re-check the transcription of the surrounding cells before touching the interpolation.
- [ ] **Step 5: Write `docs/ejma/appendix-i-transcription.md`** — for each table: PDF page, then the full array as entered in a Markdown table, with a sign-off line ("Checked by: ____ Date: ____") for the company engineer. Header note: internal document, EJMA copyright, not for publication.
- [ ] **Step 6: Commit** `git commit -m "feat(ejma): add Appendix I coefficient tables and interpolation"`

### Task 3: Derived geometry and movements (§1.3, §4.1–4.3)

**Files:**
- Create: `app/Ejma/Derived.php`, `app/Ejma/Movement.php`
- Test: `tests/Unit/Ejma/MovementTest.php`, `tests/Unit/Ejma/Fixtures/Benchmarks.php`

**Interfaces:**
- Consumes: `BellowsGeometry`, `DesignConditions`, `Coefficients` (Tasks 1–2)
- Produces:
  - `final readonly class Derived` built by `Derived::of(BellowsGeometry $g, DesignConditions $c): self` with public floats: `Dm` (`Db + w + n·t` for U-shape; `DmToroidal` for toroidal), `tp` (`t·√(Db/Dm)`), `Ac` (§1.3 round-bellows formula; toroidal per §4.13.3 symbols), `Lb` (`N·q`), `Dc` (`Db + 2nt + tc`), `Ld` (given, else `Lt + q/2` — verified against benchmark 3 S1), `k` (`min(1, Lt/(1.5√(Db·t)))`), `epsilonF` (§1.3 forming strain, %), `Cc` (`−0.2431 + 0.0168ng + 0.3024ng²`), `Cr` (`0.3 − (100/(0.6P^1.5 + 320))²`).
  - `final readonly class Movement` built by `Movement::of(BellowsGeometry, DesignConditions, Derived, float $Ktheta = 1.0): self` with public floats `exComp, exExt, ey (compression case, eq. 4-7 with Lb−x), eyExt (Lb+x), etheta, ec, ee, e` and `Kr`. `e` is the total equivalent axial movement **range** per §4.3 (p066); for benchmark 1 it equals `ec + exExt`. `Kr` per §1.3 (greater of the extension/compression expressions, not less than 1.0).
  - `Tests\Unit\Ejma\Fixtures\Benchmarks`: `case1(): array{geometry: BellowsGeometry, conditions: DesignConditions, properties: BellowsProperties, expected: array<string,float>}`, `case3()`, `case4()` with the values below.

  Benchmark inputs (p097; w from `Db + 2(w + nt) = 27`):

  | | case1 unreinforced | case3 reinforced | case4 toroidal |
  |---|---|---|---|
  | geometry | Db 24, w 1.44, t .03, n 2, rm .25, q 1, N 12, Lt 1 | Db 24, w 1.44, t .03, n 2, rm .25, q 1, N 8, Lt 1.25, tc .375, Ar .15, Atc .43, Zc .0872, ng 8, fw 14751 | Db 24, DmToroidal 27.496, t .05, n 1, q 3.4625, N 2, tc 1, Ar 2.282, Atc 1.27, Zc .271, ng 12, fw 15714, r 1, Dr 25.1, Ld 2.106 |
  | conditions | P 40, xComp 1, xExt .5, y .06, θ 5° | P 100, xComp 1, xExt .5, y 0, θ 5° | P 500, xComp .75, xExt 0, y 0, θ 0 |
  | properties | EbRt 28.3e6, EbDt 25.8e6, Sy 59726, fatigue ejmaAustenitic(type) | + EcDt 27.3e6, ErDt 26.6e6 | + EcDt 27.3e6, ErDt 26.6e6 |

  Sab/Sac/Sar/Cm are not part of the benchmark: use 20000/20000/20000/1.5.

  Expected (p098):
  - case1: S1 6301, S2 2645, S3 495, S4 17972, S5 689, S6 109067, St 122681, Nc 74317, Psc 93, Psi 128, fi 12562, Cp .7342, Cf 1.4703, Cd 1.5324, Kr 1.0417, e .2525
  - case3: S1 3294, S1p 3613, S1pp 12105, S2 3810, S2p 3929, S3 841, S4 24431, S5 2003, S6 253583, St 273276, Nc 8213, Psc 307, fi 24548, Cp .7342, Cf 1.4703, Cd 1.5324, Kr 1.0625, e .3756
  - case4: S1 8992, S1p 10407, S1pp 12975, S2 5352, S2p 9520, S3 11123, S5 2529, S6 87937, St 123836, Nc 50710, Psc 1851, fi 15714, B1 3.7463, B2 1.0146, B3 2.3731, e .3750

- [ ] **Step 1: Write failing tests** `MovementTest`: `test_benchmark1_e_and_kr` (e .2525, Kr 1.0417; lateral present so Cθ = Kθ = 1), `test_benchmark4_e` (.3750), `test_lateral_with_compression_exceeding_length_throws` (Lb 2, xComp 2, y 0.1 → `EjmaInputException` field `x_comp`). Benchmark 3's e and Kr need Kθ < 1, which depends on the spring rate, so they are asserted in Task 5 through the checker.
- [ ] **Step 2: Run** `php artisan test --filter=MovementTest` — Expected: FAIL.
- [ ] **Step 3: Implement** `Derived` and `Movement` from §1.3 (p017–p023) and eqs. 4-1…4-9 plus §4.3 (p064–p066). Single joint: Ku = 1.5 (eq. 4-7).
- [ ] **Step 4: Run** — Expected: PASS.
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): add derived geometry and movement per convolution"`

### Task 4: CheckResult, fatigue, unreinforced checker (benchmark 1)

**Files:**
- Create: `app/Ejma/LineStatus.php`, `app/Ejma/Verdict.php`, `app/Ejma/CheckLine.php`, `app/Ejma/CheckResult.php`, `app/Ejma/Fatigue.php`, `app/Ejma/Checker.php`, `app/Ejma/UnreinforcedBellows.php`
- Test: `tests/Unit/Ejma/UnreinforcedBellowsTest.php`, `tests/Unit/Ejma/FatigueTest.php`

**Interfaces:**
- Consumes: Tasks 1–3
- Produces:
  - `enum LineStatus: string { Pass='pass'; Fail='fail'; NotEvaluated='not_evaluated'; }`
  - `enum Verdict: string { Pass='pass'; Fail='fail'; Review='review'; public function label(): string }` — labels exactly: "Your design passes all EJMA checks", "Your design does not pass EJMA checks", "Your design needs engineering review".
  - `final readonly class CheckLine`: `string $key, string $label, string $equation, ?float $value, ?float $limit, string $limitExpression, LineStatus $status`; `margin(): ?float` (`(limit − value)/limit`), `toArray(): array`, `static fromArray(array): self`.
  - `final class CheckResult`: `__construct(BellowsType $type, array $lines /* CheckLine[] */, array $values /* string => float */, array $notes = [])`; `verdict(): Verdict` (Review if any NotEvaluated and none Fail; Fail if any Fail; else Pass); `firstFailure(): ?CheckLine`; `withLines(array $extra): self`; `toArray(): array`; `static fromArray(array): self`.
  - `final class Fatigue`: `static cycles(float $St, ?FatigueConstants $k): ?float` — returns `null` when `$k` is null, `INF` when `St ≤ b`.
  - `interface Checker { public function check(BellowsGeometry $g, DesignConditions $c, BellowsProperties $p): CheckResult; }`
  - `UnreinforcedBellows implements Checker` — values keys: `S1, S1p, S2, S3, S4, S5, S6, St, Nc, Psc, Psi, fi, Cp, Cf, Cd, Kr, e`. Lines: `hoop_tangent` (S1 ≤ Cwb·Sab, 4-27), `hoop_collar` (S1p ≤ Cwc·Sac, 4-28; only when tc > 0), `hoop_bellows` (S2 ≤ Cwb·Sab, 4-29), `meridional` (S3+S4 ≤ Cm·Sab, 4-30/4-31), `fatigue` (Nc ≥ requiredCycles, 4-34; NotEvaluated when constants null; Pass with value INF), `squirm_column` (P ≤ Psc, 4-35), `squirm_inplane` (P ≤ Psi, 4-36).

- [ ] **Step 1: Write failing tests** `UnreinforcedBellowsTest::test_benchmark_1` — every key of `Benchmarks::case1()['expected']` asserted with `EjmaAssertions`; `FatigueTest`: `test_st_below_b_is_infinite` (`cycles(50000, ejmaAustenitic(Unreinforced)) === INF`), `test_missing_constants_returns_null`, `test_verdict_review_when_fatigue_not_evaluated` (case1 with `fatigue: null`, `requiredCycles: 1000` → `Verdict::Review`), `test_verdict_fail_names_first_failure` (case1 with Sab 1000 → Fail, `firstFailure()->key === 'hoop_tangent'`).
- [ ] **Step 2: Run** `php artisan test --filter="UnreinforcedBellowsTest|FatigueTest"` — Expected: FAIL.
- [ ] **Step 3: Implement** eqs. 4-27…4-37 (p091–p092). St = 0.7(S3+S4) + (S5+S6). S5/S6 use EbRt. Cθ, Kθ, K2, K4, δ, α per §1.3 / §4.12.1.6. Where the text leaves the modulus for fi or S1 ambiguous, pick the one that reproduces benchmark 1 and note it in a one-line comment.
- [ ] **Step 4: Run** — Expected: PASS.
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): add unreinforced bellows checker verified by benchmark 1"`

### Task 5: Reinforced checker (benchmark 3)

**Files:**
- Create: `app/Ejma/ReinforcedBellows.php`
- Test: `tests/Unit/Ejma/ReinforcedBellowsTest.php`

**Interfaces:**
- Consumes: Tasks 1–4
- Produces: `ReinforcedBellows implements Checker`; values keys `S1, S1p, S1pp, S2, S2p, S3, S4, S5, S6, St, Nc, Psc, fi, Cp, Cf, Cd, Kr, e`. Integral reinforcing members only (R = R1 = Ac·Eb/(Ar·Er)). Lines: `hoop_tangent` (4-38), `hoop_collar` (4-39), `collar_bending` (S1p+S1pp ≤ Ks·Cwc·Sac, 4-40; Ks per p094 note / Table III), `hoop_bellows` (4-41), `hoop_reinforcement` (S2p ≤ Cwr·Sar, 4-42), `meridional` (4-44/4-45), `fatigue` (4-48), `squirm_column` (4-49). Fg uses `fw` when given, else §1.3 definition.

- [ ] **Step 1: Write failing test** `test_benchmark_3` — every key of `Benchmarks::case3()['expected']`.
- [ ] **Step 2: Run** `php artisan test --filter=ReinforcedBellowsTest` — Expected: FAIL.
- [ ] **Step 3: Implement** eqs. 4-38…4-50 (p093–p094).
- [ ] **Step 4: Run** `php artisan test tests/Unit/Ejma` — Expected: PASS (e .3756 and Kr 1.0625 come from `Movement::of(..., $Ktheta)` with Kθ computed from Cθ and φ per §1.3).
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): add reinforced bellows checker verified by benchmark 3"`

### Task 6: Toroidal checker (benchmark 4)

**Files:**
- Create: `app/Ejma/ToroidalBellows.php`
- Test: `tests/Unit/Ejma/ToroidalBellowsTest.php`

**Interfaces:**
- Consumes: Tasks 1–4
- Produces: `ToroidalBellows implements Checker`; values keys `S1, S1p, S1pp, S2, S2p, S3, S5, S6, St, Nc, Psc, fi, B1, B2, B3, e`. Lines: `hoop_tangent` (4-51), `hoop_collar` (4-52), `collar_bending` (4-53, with 4-52 per p095 limits), `hoop_bellows` (4-54), `hoop_reinforcement` (4-55), `meridional` (S3 ≤ Sab, 4-56), `fatigue` (4-59, St = 3S3 + S5 + S6), `squirm_column` (4-60). No in-plane squirm line.

- [ ] **Step 1: Write failing test** `test_benchmark_4` — every key of `Benchmarks::case4()['expected']`.
- [ ] **Step 2: Run** `php artisan test --filter=ToroidalBellowsTest` — Expected: FAIL.
- [ ] **Step 3: Implement** eqs. 4-51…4-61 (p095–p096).
- [ ] **Step 4: Run** — Expected: PASS.
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): add toroidal bellows checker verified by benchmark 4"`

### Task 7: Materials data, property resolution, loads, facade

**Files:**
- Create: `config/ejma/materials.php`, `app/Ejma/Data/Material.php`, `app/Ejma/Data/MaterialRepository.php`, `app/Ejma/PropertyResolver.php`, `app/Ejma/Loads.php`, `app/Ejma/CalculationRequest.php`, `app/Ejma/EjmaCalculator.php`
- Test: `tests/Unit/Ejma/MaterialRepositoryTest.php`, `tests/Unit/Ejma/PropertyResolverTest.php`, `tests/Unit/Ejma/EjmaCalculatorTest.php`

**Interfaces:**
- Consumes: Tasks 1–6
- Produces:
  - `config/ejma/materials.php` returns `['materials' => [id => ['name', 'family' => 'austenitic'|'nickel'|'other', 'roles' => [...], 'creep_limit_c' => ?float, 'allowable_mpa' => [°C => MPa], 'modulus_gpa' => [°C => GPa], 'yield_mpa' => [°C => MPa], 'fatigue' => ['unreinforced' => ['a','b','c'], ...] (optional; b and c in psi)]]]`. Seed ids: `ss304, ss304l, ss316, ss316l, ss321, inconel625, incoloy800, incoloy825` (roles bellows/collar/reinforcement) and `sa516_70` (collar/reinforcement), all tables **empty**, with a file header comment naming the source (ASME II-D) and that 20 °C rows are required.
  - `final readonly class Data\Material`: `id, name, family (MaterialFamily), roles (string[]), ?creepLimitC`; `hasData(): bool` (allowable and modulus non-empty); `saPsi(float $tC): float`, `ePsi(float $tC): float`, `yieldPsi(float $tC): float` (linear interpolation; outside range → `EjmaInputException` field `design_temperature`); `fatigue(BellowsType): ?FatigueConstants` (config value, else `ejmaAustenitic` when family is Austenitic, else null).
  - `final class Data\MaterialRepository`: `__construct(array $config)`; `find(string $id): ?Material`; `availableFor(string $role): array` (only `hasData()` materials).
  - `final class PropertyResolver`: `static cm(FormingCondition, FormingMethod, MaterialFamily, float $epsilonF): float` (annealed 1.5; as-formed 1.5·Ysm clamped [1.5, 3.0]; Ysm polynomials per §1.3 p021); `static resolve(Material $bellows, ?Material $collar, ?Material $reinf, FormingCondition, FormingMethod, Derived, float $tF, array $overrides, float $Cwb, float $Cwc, float $Cwr): BellowsProperties` — Sy = 0.67·Cm·Sym·Syh/Syc (Sym default Syc); overrides keys `Sab, EbRt, EbDt, Sy, Sym` replace computed values.
  - `final class Loads`: `static of(BellowsGeometry, DesignConditions, Derived, CheckResult): array` returning `['Ksr' => fi/N, 'thrust' => P·π·Dm²/4, 'spring_force' => Ksr·max(xComp, xExt)]` (lbf/in, lbf, lbf).
  - `final readonly class CalculationRequest`: `BellowsGeometry $geometry, DesignConditions $conditions, float $designTempF, string $bellowsMaterial, ?string $collarMaterial, ?string $reinforcementMaterial, FormingCondition $condition, FormingMethod $method, float $Cwb, float $Cwc, float $Cwr, array $overrides`.
  - `final class EjmaCalculator`: `__construct(MaterialRepository $materials)`; `calculate(CalculationRequest $r): CheckResult` — resolves materials (unknown/no-data id → `EjmaInputException` field `bellows_material` / `collar_material` / `reinforcement_material`), rejects `designTempF` above `creepLimitC` (field `design_temperature`, message "Design temperature is in the creep range; contact us for a creep-range design"), dispatches by type, appends `Loads` to values and `overrides_used` to notes.

- [ ] **Step 1: Write failing tests**
  - `MaterialRepositoryTest`: `test_interpolates_linearly` (fixture config 20 °C→138 MPa, 300 °C→118 MPa; `saPsi(160)` = 128 MPa in psi), `test_outside_range_throws`, `test_material_without_data_hidden`, `test_austenitic_defaults_to_figure_4_20_constants`, `test_nickel_without_constants_returns_null`.
  - `PropertyResolverTest`: `test_annealed_cm_is_1_5`, `test_as_formed_cm_clamped_to_3` (very large εf), `test_overrides_win`.
  - `EjmaCalculatorTest`: `test_creep_range_rejected`, `test_unknown_material_rejected`, `test_full_run_returns_loads` (fixture material with data + case1 geometry → values contain `thrust`, `Ksr`).
- [ ] **Step 2: Run** `php artisan test --filter="MaterialRepositoryTest|PropertyResolverTest|EjmaCalculatorTest"` — Expected: FAIL.
- [ ] **Step 3: Implement** the files listed; register `EjmaCalculator` as a singleton in `AppServiceProvider` built from `config('ejma.materials')`.
- [ ] **Step 4: Run** `php artisan test tests/Unit/Ejma` — Expected: PASS (all engine tests).
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): add material data, property resolution and calculator facade"`

### Task 8: Storage — migration, model, reference numbers

**Files:**
- Create: `database/migrations/2026_10_11_000001_create_ejma_calculations_table.php`, `app/Models/EjmaCalculation.php`
- Test: `tests/Feature/EjmaCalculationModelTest.php`

**Interfaces:**
- Consumes: `CheckResult::toArray/fromArray`, `Verdict` (Task 4)
- Produces: table `ejma_calculations` (`id`, `reference` string unique, `bellows_type` string, `verdict` string, `inputs` json, `results` json, `contact` json, `ip_address` string nullable, `emailed_at` timestamp nullable, timestamps). Model `EjmaCalculation` with casts (`inputs`/`results`/`contact` → array, `emailed_at` → datetime), `static nextReference(?CarbonInterface $now = null): string`, `result(): CheckResult`, `verdictEnum(): Verdict`.

- [ ] **Step 1: Write failing tests** `test_first_reference_of_year` (`EJ-2026-0001`), `test_sequence_increments` (after one row → `EJ-2026-0002`), `test_sequence_restarts_next_year` (row in 2026, now 2027 → `EJ-2027-0001`), `test_result_round_trips`.
- [ ] **Step 2: Run** `php artisan test --filter=EjmaCalculationModelTest` — Expected: FAIL.
- [ ] **Step 3: Implement** — `nextReference` = highest existing number for the year + 1, zero-padded to 4; creation in Task 9 wraps it in a transaction and retries once on unique violation.
- [ ] **Step 4: Run** — Expected: PASS.
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): store calculations with yearly reference numbers"`

### Task 9: Calculator page, form, submission and result screen

**Files:**
- Create: `app/Http/Controllers/PublicSite/EjmaCalculatorController.php`, `app/Http/Requests/EjmaCalculationRequest.php`, `resources/views/public/toolkit/ejma-bellows-calculator.blade.php`
- Modify: `routes/web.php` (two routes + sitemap `$toolkits` entry), `resources/views/public/toolkit/index.blade.php` (hub card), `public/llms.txt`, `public/llms-full.txt`
- Test: `tests/Feature/EjmaCalculatorPageTest.php`

**Interfaces:**
- Consumes: `EjmaCalculator`, `CalculationRequest`, `EjmaInputException` (Task 7), `EjmaCalculation` (Task 8)
- Produces:
  - `EjmaCalculationRequest::toCalculationRequest(): App\Ejma\CalculationRequest` — converts from `units` = `metric` (mm, bar(g), °C, deg) or `us` (in, psig, °F, deg).
  - Form field names (used by tests and Task 10): `units, bellows_type, design_pressure, design_temperature, required_cycles, x_comp, x_ext, lateral, angular, Db, w, t, n, N, q, rm, Lt, tc, Lc, Ld, Ar, Atc, Zc, ng, r, Dr, Dm, fw, bellows_material, collar_material, reinforcement_material, forming_condition, forming_method, Cwb, Cwc, Cwr, override_Sab, override_EbRt, override_EbDt, override_Sy, override_Sym, name, company, email, phone, notes, website` (honeypot).
  - Controller `store` persists, then calls `App\Mail\EjmaCalculationReport` sending (Task 10 provides the mailable; in this task send nothing and leave a single `$this->sendReport($calculation)` private method that Task 10 fills), then `redirect()->to('/toolkit/ejma-bellows-calculator/#result')->with('ejma_result', ['reference' => ..., 'verdict' => ...])`.
  - Result block copy: verdict label (`Verdict::label()`), "Reference **EJ-…**", "The full calculation has been sent to our engineering team. Contact us to receive the detailed results.", button `mailto:{contact address}?subject=EJMA%20calculation%20{reference}` labelled "Email us for the results". Contact address from `config('mail.contact_to')`.

- [ ] **Step 1: Write failing tests** (use a test material config with data via `config(['ejma.materials' => ...])` and rebind the singleton)
  - `test_page_renders_and_is_linked` — GET 200, sees "EJMA Bellows Calculator"; hub `/toolkit/` contains `/toolkit/ejma-bellows-calculator/`; sitemap contains `<loc>https://misubaguna.com/toolkit/ejma-bellows-calculator/</loc>`.
  - `test_only_materials_with_data_are_offered` — select options contain the fixture id, not `inconel625`.
  - `test_valid_submission_stores_and_shows_verdict_only` — POST case-1-like metric payload → redirect; follow → sees verdict label, `EJ-2026-0001`, `mailto:` with `EJ-2026-0001`; `assertDontSee` the computed S1 value (formatted 0 and 1 decimals) and `assertDontSee('S3+S4')`; one `ejma_calculations` row.
  - `test_invalid_submission_shows_field_errors` — missing `Db` → session error on `Db`, no row.
  - `test_engine_input_error_maps_to_field` — geometry giving T > 1 → session error on `geometry`-mapped field `rm`, no row; creep temperature → error on `design_temperature`; tampered `bellows_material=inconel625` → error on `bellows_material`.
  - `test_honeypot_discards` — `website` filled → redirect with no row.
  - `test_rate_limited` — 6th POST within the hour → 429.
- [ ] **Step 2: Run** `php artisan test --filter=EjmaCalculatorPageTest` — Expected: FAIL.
- [ ] **Step 3: Implement** controller (`index` mirrors `ToolkitController::expansionJointSelector` SEO/breadcrumb/`webApplicationSchema` pattern), FormRequest (rules per bellows type with `required_if`; numeric `gt:0` for dimensions; `in:` for enums; material ids validated against `availableFor(role)`), view (sections per spec §4.2, JS only shows/hides type-specific fieldsets and relabels units; result block rendered from session flash; honeypot hidden like the contact form), routes, hub card, sitemap entry, llms entries. `EjmaInputException::$field` `geometry` maps to `rm` (U-shaped) or `r` (toroidal).
- [ ] **Step 4: Run** `php artisan test --filter="EjmaCalculatorPageTest|ToolkitSelectorPagesTest|SeoAndAiDiscoveryTest"` — Expected: PASS.
- [ ] **Step 5: Verify in browser** — start the Herd site, open `/toolkit/ejma-bellows-calculator/`, switch bellows types and units, submit a valid case, screenshot the result block; check console has no errors; check 375 px width has no horizontal scroll.
- [ ] **Step 6: Commit** `git commit -m "feat(ejma): add public calculator page with gated result screen"`

### Task 10: Report email, PDF, resend command

**Files:**
- Create: `app/Mail/EjmaCalculationReport.php`, `resources/views/emails/ejma-calculation.blade.php`, `resources/views/pdf/ejma-calculation.blade.php`, `app/Console/Commands/EjmaResend.php`
- Modify: `composer.json` (`barryvdh/laravel-dompdf`), `app/Http/Controllers/PublicSite/EjmaCalculatorController.php` (`sendReport`)
- Test: `tests/Feature/EjmaReportTest.php`

**Interfaces:**
- Consumes: `EjmaCalculation` (Task 8), `CheckResult`, `Verdict` (Task 4)
- Produces: `new EjmaCalculationReport(EjmaCalculation $calc)` — to `config('mail.contact_to')`, `replyTo` visitor email/name, subject `EJMA calc {ref} — {company} — {Db mm} mm {type} — {VERDICT}` plus ` ({firstFailure label})` when Fail; attachment `{ref}.pdf` (`application/pdf`) rendered from the PDF view. `sendReport(EjmaCalculation): void` sends synchronously, sets `emailed_at` on success, `report($e)` on failure. Artisan `ejma:resend {reference}` → resends, sets `emailed_at`, exits 1 with message when the reference is unknown.
- PDF sections exactly as spec §5 items 1–6; disclaimer text: "Preliminary calculation for quotation purposes, to be confirmed by PT Misuba Guna Indonesia engineering. Not a substitute for a certified design." Header line: "Calculated per EJMA Standards, 9th Edition". Overrides flagged "(override)".

- [ ] **Step 1: Write failing tests**
  - `test_submission_sends_report_with_pdf` — `Mail::fake()`; POST valid payload; assert `EjmaCalculationReport` sent to `marketing@misubaguna.com`, has reply-to visitor, subject contains reference and verdict, attachment named `EJ-2026-0001.pdf`; row `emailed_at` not null.
  - `test_pdf_contains_results` — render the mailable's PDF view HTML for a stored case-1 calculation; sees "4-27", "EJMA Standards, 9th Edition", the S1 value.
  - `test_mail_failure_still_shows_result` — bind a mailer that throws; POST → result screen shows verdict; row `emailed_at` null.
  - `test_resend_command` — `artisan ejma:resend EJ-2026-0001` exit 0, mail sent, `emailed_at` set; unknown ref exit 1.
- [ ] **Step 2: Run** `php artisan test --filter=EjmaReportTest` — Expected: FAIL.
- [ ] **Step 3: Install** `composer require barryvdh/laravel-dompdf` and implement.
- [ ] **Step 4: Run** `php artisan test` — Expected: full suite PASS.
- [ ] **Step 5: Commit** `git commit -m "feat(ejma): email calculation report with PDF and add resend command"`

---

## Self-review notes

- Spec coverage: §2 scope → Tasks 4–7 (types) and FormRequest rules; §3.1 → Tasks 1–7; §3.2 → Task 7; §3.3 → Task 8 + `ejma:resend` Task 10; §4 → Task 9; §5 → Task 10; §6.1 → Tasks 1–7; §6.2 → Tasks 8–10; §6.3 → Task 2 Step 5; §7 → Global Constraints.
- Go-live remains blocked on the company populating `config/ejma/materials.php` and signing off `docs/ejma/appendix-i-transcription.md` (spec §8); with empty data the page renders but offers no materials.
