<?php

namespace Tests\Private\Ejma;

use App\Ejma\BellowsType;
use App\Ejma\CheckResult;
use App\Ejma\Derived;
use App\Ejma\DesignConditions;
use App\Ejma\Fatigue;
use App\Ejma\FatigueConstants;
use App\Ejma\Movement;
use App\Ejma\ReinforcedBellows;
use App\Ejma\ToroidalBellows;
use App\Ejma\UnreinforcedBellows;
use PHPUnit\Framework\TestCase;
use Tests\Private\Ejma\Fixtures\BenchmarkResults;
use Tests\RequiresEjmaData;
use Tests\Unit\Ejma\EjmaAssertions;
use Tests\Unit\Ejma\Fixtures\Benchmarks;

/**
 * PRIVATE (git-ignored): the engine against the published EJMA 9th Ed. §4.14 benchmark results
 * (p098). Never commit this file.
 */
class BenchmarkResultsTest extends TestCase
{
    use EjmaAssertions;
    use RequiresEjmaData;

    private const COEFFICIENTS = ['Cp', 'Cf', 'Cd', 'B1', 'B2', 'B3'];

    private const RATIOS = ['Kr', 'e'];

    /**
     * @param  array<string, float>  $expected
     * @param  list<string>  $skip
     */
    private function assertBenchmark(array $expected, CheckResult $result, array $skip = []): void
    {
        foreach ($expected as $key => $value) {
            $this->assertArrayHasKey($key, $result->values, "value $key");
            if (in_array($key, $skip, true)) {
                continue;
            }
            $actual = $result->values[$key];
            if (in_array($key, self::COEFFICIENTS, true)) {
                $this->assertCoefficient($value, $actual, $key);
            } elseif (in_array($key, self::RATIOS, true)) {
                $this->assertRatio($value, $actual, $key);
            } else {
                $this->assertEjmaValue($value, $actual, $key);
            }
        }
    }

    public function test_benchmark_1(): void
    {
        $b = Benchmarks::case1();
        $result = (new UnreinforcedBellows)->check($b['geometry'], $b['conditions'], $b['properties']);

        $this->assertSame(BellowsType::Unreinforced, $result->type);
        $this->assertBenchmark(BenchmarkResults::case1(), $result);
    }

    public function test_benchmark_1_line_margins(): void
    {
        $b = Benchmarks::case1();
        $c = $b['conditions'];
        $conditions = new DesignConditions($c->P, $c->xComp, $c->xExt, $c->y, $c->theta, 1000);
        $result = (new UnreinforcedBellows)->check($b['geometry'], $conditions, $b['properties']);
        $lines = [];
        foreach ($result->lines as $line) {
            $lines[$line->key] = $line;
        }

        // Nc = 74317 vs 1000 required: margin (Nc − 1000)/1000 > 0 on a pass.
        $this->assertEqualsWithDelta((74317.43 - 1000) / 1000, $lines['fatigue']->margin(), 0.5);
        $this->assertEqualsWithDelta((30000 - 18464.87) / 30000, $lines['meridional']->margin(), 1e-3);
    }

    public function test_benchmark_1_angular_only_squirm(): void
    {
        $b = Benchmarks::case1();
        $c = $b['conditions'];
        $angularOnly = new DesignConditions($c->P, $c->xComp, $c->xExt, 0, $c->theta, null);
        $result = (new UnreinforcedBellows)->check($b['geometry'], $angularOnly, $b['properties']);

        // Ctheta = 0.1157^theta_m (§1.3 p018) with theta_m = 5° in radians.
        $this->assertEqualsWithDelta(93.18 * 0.1157 ** deg2rad(5), $result->values['Psc'], 0.1);
    }

    public function test_benchmark_1_cycles(): void
    {
        $this->assertEjmaValue(74317, Fatigue::cycles(122681, FatigueConstants::ejmaAustenitic(BellowsType::Unreinforced)), 'Nc');
    }

    public function test_benchmark_2(): void
    {
        $b = Benchmarks::case2();
        $result = (new UnreinforcedBellows)->check($b['geometry'], $b['conditions'], $b['properties']);

        $this->assertSame(BellowsType::Unreinforced, $result->type);
        $this->assertBenchmark(BenchmarkResults::case2(), $result);
    }

    public function test_benchmark_3(): void
    {
        $b = Benchmarks::case3();
        $expected = BenchmarkResults::case3();
        $result = (new ReinforcedBellows)->check($b['geometry'], $b['conditions'], $b['properties']);
        $v = $result->values;

        $this->assertSame(BellowsType::Reinforced, $result->type);
        // Psc and Nc are documented deviations, asserted below.
        $this->assertBenchmark($expected, $result, ['Psc', 'Nc']);

        // Kθ with φ = P/(limiting squirm pressure without Cθ) = PN²q/(0.3π fir) (AngularPressureFactor):
        // Cθ = 0.1157^θm = 0.8284, φ = 0.2766, Kθ = 0.7352 → e = 0.3767 (published 0.3756, +0.29 %).
        $this->assertEqualsWithDelta(0.82844, $v['Ctheta'], 1e-5);
        $this->assertEqualsWithDelta(100 * 64 / (0.3 * M_PI * $v['fi']), $v['phi'], 1e-9);
        $this->assertEqualsWithDelta(0.7352, $v['Ktheta'], 1e-4);

        // Known deviation: eq. 4-49 as written gives Psc = 0.3π·Cθ·fir/(N²q) = 299.5; the published
        // 307 is ~2.5 % higher and no reading of the text reproduces it. 299.5 is the conservative side.
        $this->assertEqualsWithDelta(299.48, $v['Psc'], 0.05);

        // Nc is steep in St (exponent 2.9): e +0.29 % (from the Psc gap above, since e uses P/Psc)
        // puts St +0.27 % and Nc −0.9 % (8138 vs 8213). Case-3-only tolerance of 1.5 %;
        // at the published e = 0.3756 the same equations give Nc = 8212.
        $this->assertEqualsWithDelta($expected['Nc'], $v['Nc'], 0.015 * $expected['Nc'], 'Nc');
    }

    public function test_benchmark_4(): void
    {
        $b = Benchmarks::case4();
        $result = (new ToroidalBellows)->check($b['geometry'], $b['conditions'], $b['properties']);

        $this->assertSame(BellowsType::Toroidal, $result->type);
        $this->assertBenchmark(BenchmarkResults::case4(), $result);
        // Benchmark 4 has collar bending 10407 + 12975 = 23382 ≤ 30000 → passes.
        $this->assertEqualsWithDelta(10407 + 12975, $result->values['S1p'] + $result->values['S1pp'], 0.005 * 23382);
    }

    public function test_benchmark_movements(): void
    {
        $one = Benchmarks::case1();
        $m = Movement::of($one['geometry'], $one['conditions'], Derived::of($one['geometry'], $one['conditions']), 1.0);
        $this->assertRatio(0.0927, $m->etheta, 'etheta');
        $this->assertRatio(0.0348, $m->ey, 'ey');
        $this->assertRatio(0.2108, $m->ec, 'ec');
        $this->assertRatio(BenchmarkResults::case1()['e'], $m->e, 'e');
        $this->assertRatio(BenchmarkResults::case1()['Kr'], $m->Kr, 'Kr');

        $two = Benchmarks::case2();
        $m = Movement::of($two['geometry'], $two['conditions'], Derived::of($two['geometry'], $two['conditions']), 1.0);
        $this->assertRatio(BenchmarkResults::case2()['e'], $m->e, 'e universal');
        $this->assertRatio(BenchmarkResults::case2()['Kr'], $m->Kr, 'Kr universal');

        $four = Benchmarks::case4();
        $m = Movement::of($four['geometry'], $four['conditions'], Derived::of($four['geometry'], $four['conditions']));
        $this->assertRatio(BenchmarkResults::case4()['e'], $m->e, 'e toroidal');
    }
}
